// Função utilitária para download e conversão de mídia em base64
export async function downloadMediaAsBase64(mediaUrl: string): Promise<string | null> {
  try {
    console.log(`📥 [MEDIA_UTILS] Downloading media from: ${mediaUrl.substring(0, 100)}...`);
    
    const response = await fetch(mediaUrl);
    if (!response.ok) {
      console.error(`❌ [MEDIA_UTILS] Failed to download media: ${response.status}`);
      return null;
    }

    const arrayBuffer = await response.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // Converter para string base64
    const base64 = btoa(
      Array(uint8Array.length)
        .fill('')
        .map((_, i) => String.fromCharCode(uint8Array[i]))
        .join('')
    );
    
    // Determinar o tipo MIME com base na URL ou cabeçalhos
    const contentType = response.headers.get('content-type') || getMimeTypeFromUrl(mediaUrl);
    
    // Retornar o formato completo data:mimetype;base64,DATA
    const fullBase64 = `data:${contentType};base64,${base64}`;
    
    console.log(`✅ [MEDIA_UTILS] Media converted to base64, size: ${(fullBase64.length / 1024).toFixed(2)} KB, type: ${contentType}`);
    
    return fullBase64;
  } catch (error) {
    console.error(`❌ [MEDIA_UTILS] Error downloading media:`, error);
    return null;
  }
}

// Função para tentar determinar o tipo MIME com base na URL
function getMimeTypeFromUrl(url: string): string {
  const extension = url.split('.').pop()?.toLowerCase();
  
  if (!extension) return 'application/octet-stream';
  
  switch (extension) {
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'gif':
      return 'image/gif';
    case 'webp':
      return 'image/webp';
    case 'mp3':
      return 'audio/mpeg';
    case 'wav':
      return 'audio/wav';
    case 'ogg':
      return 'audio/ogg';
    case 'mp4':
      return 'video/mp4';
    case 'webm':
      return 'video/webm';
    case 'pdf':
      return 'application/pdf';
    case 'doc':
    case 'docx':
      return 'application/msword';
    case 'xls':
    case 'xlsx':
      return 'application/vnd.ms-excel';
    case 'ppt':
    case 'pptx':
      return 'application/vnd.ms-powerpoint';
    default:
      return 'application/octet-stream';
  }
}

export function getMediaTypeFromMessage(message: any): string {
  if (message.imageMessage) return 'image';
  if (message.audioMessage) return 'audio';
  if (message.videoMessage) return 'video';
  if (message.documentMessage) return 'document';
  return 'text';
}

export function getMediaUrlFromMessage(message: any): string | null {
  if (message.imageMessage?.url) return message.imageMessage.url;
  if (message.audioMessage?.url) return message.audioMessage.url;
  if (message.videoMessage?.url) return message.videoMessage.url;
  if (message.documentMessage?.url) return message.documentMessage.url;
  return null;
}

export function getMediaCaptionFromMessage(message: any, messageType: string): string {
  if (message.imageMessage?.caption) return message.imageMessage.caption;
  if (message.videoMessage?.caption) return message.videoMessage.caption;
  if (message.documentMessage?.caption) return message.documentMessage.caption;
  if (message.documentMessage?.fileName) return `[Documento: ${message.documentMessage.fileName}]`;
  
  // Fallbacks para cada tipo
  switch (messageType) {
    case 'image': return '[Imagem]';
    case 'audio': return '[Áudio]';
    case 'video': return '[Vídeo]';
    case 'document': return '[Documento]';
    default: return '[Mídia]';
  }
}

