import { useState, useEffect, useCallback } from 'react';
import { ApiInstance, ApiInstanceWithConnection } from '../types/domain/api/ApiInstance';
import { ApiInstanceService } from '../services/ApiInstanceService';

export function useApiInstances() {
  const [instances, setInstances] = useState<ApiInstance[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const apiInstanceService = new ApiInstanceService();

  const fetchInstances = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await apiInstanceService.getAllInstances();
      setInstances(data);
    } catch (err) {
      console.error('Error fetching API instances:', err);
      setError('Falha ao carregar instâncias da API');
    } finally {
      setLoading(false);
    }
  }, []);

  const createInstance = useCallback(async (instance: ApiInstance) => {
    try {
      setError(null);
      const newInstance = await apiInstanceService.createInstance(instance);
      setInstances(prev => [...prev, newInstance]);
      return newInstance;
    } catch (err) {
      console.error('Error creating API instance:', err);
      setError('Falha ao criar instância da API');
      throw err;
    }
  }, []);

  const updateInstance = useCallback(async (id: string, instance: Partial<ApiInstance>) => {
    try {
      setError(null);
      const updatedInstance = await apiInstanceService.updateInstance(id, instance);
      setInstances(prev => prev.map(i => i.id === id ? updatedInstance : i));
      return updatedInstance;
    } catch (err) {
      console.error(`Error updating API instance with ID ${id}:`, err);
      setError('Falha ao atualizar instância da API');
      throw err;
    }
  }, []);

  const deleteInstance = useCallback(async (id: string) => {
    try {
      setError(null);
      await apiInstanceService.deleteInstance(id);
      setInstances(prev => prev.filter(i => i.id !== id));
    } catch (err) {
      console.error(`Error deleting API instance with ID ${id}:`, err);
      setError('Falha ao excluir instância da API');
      throw err;
    }
  }, []);

  const getInstanceWithConnectionDetails = useCallback(async (id: string): Promise<ApiInstanceWithConnection | null> => {
    try {
      setError(null);
      return await apiInstanceService.getInstanceWithConnectionDetails(id);
    } catch (err) {
      console.error(`Error getting connection details for API instance with ID ${id}:`, err);
      setError('Falha ao obter detalhes de conexão da instância da API');
      return null;
    }
  }, []);

  useEffect(() => {
    fetchInstances();
  }, [fetchInstances]);

  return {
    instances,
    loading,
    error,
    fetchInstances,
    createInstance,
    updateInstance,
    deleteInstance,
    getInstanceWithConnectionDetails
  };
}

