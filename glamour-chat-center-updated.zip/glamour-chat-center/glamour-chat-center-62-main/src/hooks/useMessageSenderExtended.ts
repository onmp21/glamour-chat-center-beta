
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { FileService } from '@/services/FileService';

export interface FileData {
  base64: string;
  fileName: string;
  mimeType: string;
  size: number;
}

export interface ExtendedMessageData {
  conversationId: string;
  channelId: string;
  content: string;
  sender: 'customer' | 'agent';
  agentName?: string;
  messageType?: 'text' | 'file' | 'audio' | 'image' | 'video';
  fileData?: FileData;
}

export const useMessageSenderExtended = () => {
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  const sendWebhook = async (rowData: any) => {
    try {
      const webhookUrl = 'https://n8n.estudioonmp.com/webhook/3a0b2487-21d0-43c7-bc7f-07404879df5434232';
      
      console.log('🔥 Enviando dados para webhook:', rowData);

      await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        mode: 'no-cors',
        body: JSON.stringify(rowData),
      });

      console.log('✅ Webhook enviado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao enviar webhook:', error);
    }
  };

  const sendMessage = async (messageData: ExtendedMessageData): Promise<boolean> => {
    setSending(true);
    
    try {
      // Só processar se for canal Yelena
      if (messageData.channelId !== 'chat' && messageData.channelId !== 'af1e5797-edc6-4ba3-a57a-25cf7297c4d6') {
        console.log('❌ Canal não é Yelena, não processando');
        setSending(false);
        return false;
      }

      let messageContent = messageData.content;
      let messageType = messageData.messageType || 'text';

      // Se tem arquivo, usar o base64 como conteúdo
      if (messageData.fileData) {
        console.log('📎 Processando arquivo:', messageData.fileData.fileName, messageData.fileData.mimeType);
        messageContent = messageData.fileData.base64;
        messageType = FileService.getFileType(messageData.fileData.mimeType) as any;
        
        // Para imagens, garantir que esteja no formato correto
        if (messageType === 'image' && !messageContent.startsWith('data:')) {
          messageContent = `data:${messageData.fileData.mimeType};base64,${messageContent}`;
        }
      }

      // Criar dados para inserir na tabela yelena_ai_conversas
      const insertData = {
        session_id: `agent_${messageData.conversationId}_${Date.now()}`,
        message: messageContent,
        Nome_do_contato: messageData.agentName || 'Atendente',
        tipo_remetente: 'USUARIO_INTERNO',
        mensagemtype: messageType,
        read_at: new Date().toISOString()
      };

      console.log('💾 Salvando mensagem na tabela yelena_ai_conversas:', {
        ...insertData,
        message: messageType === 'text' ? insertData.message : `[${messageType.toUpperCase()}] ${messageData.fileData?.fileName || 'arquivo'}`
      });

      // Inserir na tabela - isso vai automaticamente disparar o realtime
      const { data, error } = await supabase
        .from('yelena_ai_conversas')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('❌ Erro ao salvar mensagem:', error);
        throw error;
      }

      console.log('✅ Mensagem salva com sucesso:', data);

      // Enviar webhook com todos os dados da linha inserida
      await sendWebhook(data);

      const typeMessages = {
        text: 'Mensagem enviada',
        file: 'Arquivo enviado',
        audio: 'Áudio enviado',
        image: 'Imagem enviada',
        video: 'Vídeo enviado'
      };

      toast({
        title: "Sucesso",
        description: typeMessages[messageType] + " com sucesso",
      });

      return true;
    } catch (error) {
      console.error('❌ Erro ao enviar mensagem:', error);
      toast({
        title: "Erro",
        description: "Erro ao enviar mensagem: " + (error instanceof Error ? error.message : 'Erro desconhecido'),
        variant: "destructive"
      });
      return false;
    } finally {
      setSending(false);
    }
  };

  return {
    sendMessage,
    sending
  };
};
