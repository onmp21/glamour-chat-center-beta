
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

export interface Tag {
  id: string;
  name: string;
  color: string;
  created_at: string;
  updated_at: string;
}

export const useTags = () => {
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const STORAGE_KEY = 'app_tags';

  const loadTags = async () => {
    try {
      setLoading(true);
      const storedTags = localStorage.getItem(STORAGE_KEY);
      
      if (storedTags) {
        const parsedTags = JSON.parse(storedTags);
        setTags(parsedTags);
      } else {
        // Initialize with default tags for customer service
        const defaultTags: Tag[] = [
          { id: '1', name: 'Urgente', color: '#dc2626', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
          { id: '2', name: 'Agendamento', color: '#ea580c', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
          { id: '3', name: 'Consultas', color: '#7c3aed', created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
          { id: '4', name: 'Informações', color: '#059669', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
        ];
        setTags(defaultTags);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultTags));
      }
    } catch (error) {
      console.error('Erro ao carregar tags:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar tags",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const createTag = async (name: string, color: string) => {
    try {
      const newTag: Tag = {
        id: Date.now().toString(),
        name,
        color,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const updatedTags = [...tags, newTag];
      setTags(updatedTags);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedTags));
      
      toast({
        title: "Sucesso",
        description: "Tag criada com sucesso",
      });
      return true;
    } catch (error) {
      console.error('Erro ao criar tag:', error);
      toast({
        title: "Erro",
        description: "Erro ao criar tag",
        variant: "destructive"
      });
      return false;
    }
  };

  const updateTag = async (id: string, name: string, color: string) => {
    try {
      const updatedTags = tags.map(tag => 
        tag.id === id 
          ? { ...tag, name, color, updated_at: new Date().toISOString() }
          : tag
      );
      
      setTags(updatedTags);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedTags));
      
      toast({
        title: "Sucesso",
        description: "Tag atualizada com sucesso",
      });
      return true;
    } catch (error) {
      console.error('Erro ao atualizar tag:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar tag",
        variant: "destructive"
      });
      return false;
    }
  };

  const deleteTag = async (id: string) => {
    try {
      const updatedTags = tags.filter(tag => tag.id !== id);
      setTags(updatedTags);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedTags));
      
      toast({
        title: "Sucesso",
        description: "Tag excluída com sucesso",
      });
      return true;
    } catch (error) {
      console.error('Erro ao excluir tag:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir tag",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    loadTags();
  }, []);

  return {
    tags,
    loading,
    createTag,
    updateTag,
    deleteTag,
    loadTags
  };
};
