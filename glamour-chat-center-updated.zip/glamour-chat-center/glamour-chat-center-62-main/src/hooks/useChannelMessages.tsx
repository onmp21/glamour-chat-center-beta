
import { useQuery } from '@tanstack/react-query';
import { MessageService } from '@/services/MessageService';

export interface ChannelMessage {
  id: string;
  content: string;
  timestamp: string;
  sender: 'customer' | 'agent';
  contactName: string;
  contactPhone: string;
  messageType: 'ai' | 'human';
  tipo_remetente?: string;
  Nome_do_contato?: string;
  nome_do_contato?: string;
  mensagemtype?: string;
}

export interface UseChannelMessagesResult {
  messages: ChannelMessage[];
  loading: boolean;
  error: Error | null;
  refetch: () => void;
}

export const useChannelMessages = (channelId: string, conversationId?: string): UseChannelMessagesResult => {
  const {
    data: messages = [],
    isLoading: loading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['channel-messages', channelId, conversationId],
    queryFn: async () => {
      const messageService = new MessageService(channelId);
      if (conversationId) {
        return await messageService.getMessagesByConversation(conversationId);
      }
      return await messageService.getAllMessages();
    },
    refetchInterval: 5000,
  });

  return {
    messages,
    loading,
    error: error as Error | null,
    refetch,
  };
};
