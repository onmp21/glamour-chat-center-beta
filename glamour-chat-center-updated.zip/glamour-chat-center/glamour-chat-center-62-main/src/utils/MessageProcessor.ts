import { MediaProcessor } from '@/services/MediaProcessor';

export interface RawMessage {
  id: number;
  session_id: string;
  message: string;
  Nome_do_contato?: string;
  nome_do_contato?: string;
  tipo_remetente?: string;
  mensagemtype?: string;
  read_at?: string;
  is_read?: boolean;
}

export interface ProcessedMessage {
  id: string;
  content: string;
  timestamp: string;
  sender: string;
  tipo_remetente?: string;
  isOwn?: boolean;
  agentName?: string;
  Nome_do_contato?: string;
  mensagemtype?: string;
  contactName: string;
  contactPhone: string;
  messageType: string;
}

export interface ConversationSummary {
  id: string;
  lastMessage: string;
  lastMessageTime: string;
  contactName: string;
  unreadCount: number;
  status: 'unread' | 'in_progress' | 'resolved';
  phone: string;
  // Compatibility properties for ChannelConversation interface
  contact_name: string;
  contact_phone: string;
  last_message: string;
  last_message_time: string;
  updated_at: string;
}

export class MessageProcessor {
  private static extractPhoneFromSessionId(sessionId: string): string {
    // Extrair apenas os números do session_id
    const parts = sessionId.split('-');
    if (parts.length > 1 && /^\d{10,15}$/.test(parts[0])) {
      return parts[0];
    }
    
    // Fallback: procurar sequência de números
    const phoneMatch = sessionId.match(/(\d{10,15})/);
    return phoneMatch ? phoneMatch[1] : sessionId;
  }

  private static getContactName(message: RawMessage): string {
    // CORREÇÃO: Verificar se campos não são vazios antes de usar
    const nomeDoContato = message.Nome_do_contato?.trim();
    const nomeDoContatoLower = message.nome_do_contato?.trim();
    
    console.log(`🔍 [MESSAGE_PROCESSOR] Getting contact name for message ${message.id}:`, {
      Nome_do_contato: message.Nome_do_contato,
      nome_do_contato: message.nome_do_contato,
      nomeDoContato,
      nomeDoContatoLower,
      willUse: nomeDoContato || nomeDoContatoLower || 'phone'
    });
    
    // Usar apenas se não for vazio
    if (nomeDoContato) {
      return nomeDoContato;
    }
    if (nomeDoContatoLower) {
      return nomeDoContatoLower;
    }
    
    // Fallback para telefone apenas se nomes estão realmente vazios
    return this.extractPhoneFromSessionId(message.session_id);
  }

  private static formatMessageContent(message: RawMessage): string {
    // Detectar tipo de mensagem - usar o tipo explícito ou tentar detectar
    let messageType = message.mensagemtype || 'text';
    
    // Verificar se o conteúdo parece ser base64, mesmo que o tipo não indique
    const isLikelyBase64 = message.message.length > 100 && 
                          !message.message.includes(' ') && 
                          !message.message.includes('\n') &&
                          /^[A-Za-z0-9+/=]+$/.test(message.message);
    
    console.log(`🎭 [MESSAGE_PROCESSOR] ENHANCED Processing message:`, {
      id: message.id,
      declaredType: messageType,
      contentLength: message.message.length,
      contentPreview: message.message.substring(0, 30),
      isDataUrl: message.message.startsWith('data:'),
      isLikelyBase64
    });
    
    // Se parece base64 mas não tem tipo de mídia, tentar detectar
    if (isLikelyBase64 && messageType === 'text') {
      console.log(`🔍 [MESSAGE_PROCESSOR] Content looks like base64 but type is text, attempting detection`);
      messageType = 'auto_detect';
    }
    
    // SEMPRE tentar usar MediaProcessor para tipos de mídia ou conteúdo que parece base64
    const mediaTypes = ['audio', 'mensagem_de_audio', 'image', 'mensagem_de_imagem', 'video', 'mensagem_de_video', 'document', 'file', 'auto_detect'];
    const isMediaType = mediaTypes.includes(messageType);
    
    console.log(`🔍 [MESSAGE_PROCESSOR] Media type analysis:`, {
      messageType,
      isMediaType,
      hasDataUrl: message.message.startsWith('data:'),
      contentLength: message.message.length
    });
    
    // Se é tipo de mídia ou parece base64, SEMPRE usar MediaProcessor
    if (isMediaType || isLikelyBase64) {
      console.log(`🔄 [MESSAGE_PROCESSOR] FORCING MediaProcessor for content`);
      
      const mediaResult = MediaProcessor.process(message.message, messageType);
      
      // Se o processamento foi bem-sucedido, atualizar o tipo da mensagem
      if (mediaResult.isProcessed && messageType === 'auto_detect') {
        message.mensagemtype = mediaResult.type;
      }
      
      console.log(`✅ [MESSAGE_PROCESSOR] MediaProcessor result for message ${message.id}:`, {
        wasProcessed: mediaResult.isProcessed,
        type: mediaResult.type,
        hasError: !!mediaResult.error,
        finalUrlPreview: mediaResult.url.substring(0, 100),
        size: mediaResult.size
      });
      
      return mediaResult.url;
    }
    
    // Para mensagens de texto, retornar como está
    console.log(`📝 [MESSAGE_PROCESSOR] Returning text content for message ${message.id}`);
    return message.message;
  }

  private static getPreviewForMessageType(messageType: string): string {
    switch (messageType) {
      case 'image':
        return '📸 Imagem';
      case 'audio':
        return '🎵 Áudio';
      case 'video':
        return '🎬 Vídeo';
      case 'document':
        return '📎 Documento';
      default:
        return '';
    }
  }

  static processMessages(rawMessages: RawMessage[], channelId: string): ProcessedMessage[] {
    console.log(`🔄 [MESSAGE_PROCESSOR] Processing ${rawMessages.length} messages for channel ${channelId}`);
    
    return rawMessages.map((msg): ProcessedMessage => {
      const isAgent = msg.tipo_remetente === 'USUARIO_INTERNO' || 
                     msg.tipo_remetente === 'AGENTE' ||
                     msg.tipo_remetente === 'Yelena-ai';
      
      const contactName = this.getContactName(msg);
      const content = this.formatMessageContent(msg);
      const contactPhone = this.extractPhoneFromSessionId(msg.session_id);
      const messageType = msg.mensagemtype || 'text';
      
      console.log(`📋 [MESSAGE_PROCESSOR] Processed message ${msg.id}:`, {
        messageType,
        contentLength: content.length,
        isAgent,
        contactName,
        hasDataUrl: content.startsWith('data:'),
        contentPreview: content.substring(0, 100)
      });
      
      return {
        id: msg.id.toString(),
        content,
        timestamp: msg.read_at || new Date().toISOString(),
        sender: contactPhone,
        tipo_remetente: msg.tipo_remetente,
        isOwn: isAgent,
        agentName: isAgent ? contactName : undefined,
        Nome_do_contato: contactName,
        mensagemtype: messageType,
        contactName,
        contactPhone,
        messageType
      };
    });
  }

  static groupMessagesByPhone(rawMessages: RawMessage[], channelId: string): ConversationSummary[] {
    console.log(`📱 [MESSAGE_PROCESSOR] Grouping ${rawMessages.length} messages by phone for channel ${channelId}`);
    
    const phoneGroups = new Map<string, RawMessage[]>();
    
    // Agrupar mensagens por telefone
    rawMessages.forEach(msg => {
      const phone = this.extractPhoneFromSessionId(msg.session_id);
      if (!phoneGroups.has(phone)) {
        phoneGroups.set(phone, []);
      }
      phoneGroups.get(phone)!.push(msg);
    });

    const conversations: ConversationSummary[] = [];
    
    phoneGroups.forEach((messages, phone) => {
      // CORREÇÃO: Ordenar mensagens por timestamp corretamente (mais recente primeiro para pegar a última)
      const sortedMessages = messages.sort((a, b) => {
        const timeA = new Date(a.read_at || 0).getTime();
        const timeB = new Date(b.read_at || 0).getTime();
        return timeB - timeA; // Mais recente primeiro
      });

      const lastMessage = sortedMessages[0];
      const contactName = this.getContactName(lastMessage);
      
      let previewContent = lastMessage.message;
      const messageType = lastMessage.mensagemtype || 'text';
      
      // Se é um arquivo, mostrar preview apropriado
      if (messageType !== 'text') {
        const preview = this.getPreviewForMessageType(messageType);
        previewContent = preview || previewContent;
      }
      
      // Limitar tamanho do preview para texto
      if (messageType === 'text' && previewContent.length > 50) {
        previewContent = previewContent.substring(0, 50) + '...';
      }

      // Contar mensagens não lidas
      const unreadCount = messages.filter(msg => !msg.is_read).length;
      
      // Recuperar status do localStorage
      const statusKey = `conversation_status_${channelId}_${phone}`;
      const savedStatus = localStorage.getItem(statusKey) as 'unread' | 'in_progress' | 'resolved' || 'unread';
      
      const lastMessageTime = lastMessage.read_at || new Date().toISOString();

      conversations.push({
        id: phone,
        lastMessage: previewContent,
        lastMessageTime,
        contactName,
        unreadCount,
        status: unreadCount > 0 ? 'unread' : savedStatus,
        phone,
        // Compatibility properties
        contact_name: contactName,
        contact_phone: phone,
        last_message: previewContent,
        last_message_time: lastMessageTime,
        updated_at: lastMessageTime
      });
    });

    // CORREÇÃO: Ordenar conversas por timestamp da última mensagem (mais recente primeiro)
    conversations.sort((a, b) => 
      new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime()
    );

    console.log(`✅ [MESSAGE_PROCESSOR] Created ${conversations.length} conversation summaries, ordered by most recent first`);
    
    return conversations;
  }
}
