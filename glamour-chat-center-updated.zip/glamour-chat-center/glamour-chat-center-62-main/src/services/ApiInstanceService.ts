import { ApiInstance, ApiInstanceWithConnection } from '../types/domain/api/ApiInstance';
import { ApiInstanceRepository } from '../repositories/ApiInstanceRepository';

export class ApiInstanceService {
  private repository: ApiInstanceRepository;

  constructor() {
    this.repository = new ApiInstanceRepository();
  }

  async getAllInstances(): Promise<ApiInstance[]> {
    return this.repository.getAll();
  }

  async getInstance(id: string): Promise<ApiInstance | null> {
    return this.repository.getById(id);
  }

  async createInstance(instance: ApiInstance): Promise<ApiInstance> {
    return this.repository.create(instance);
  }

  async updateInstance(id: string, instance: Partial<ApiInstance>): Promise<ApiInstance> {
    return this.repository.update(id, instance);
  }

  async deleteInstance(id: string): Promise<void> {
    return this.repository.delete(id);
  }

  async getInstanceQRCode(instanceId: string): Promise<string | null> {
    try {
      const instance = await this.repository.getById(instanceId);
      
      if (!instance) {
        throw new Error(`Instance with ID ${instanceId} not found`);
      }

      // Fazer a requisição para a API Evolution para obter o QR Code
      const response = await fetch(`${instance.base_url}/instance/qr`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'apikey': instance.api_key
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get QR code: ${response.statusText}`);
      }

      const data = await response.json();
      return data.qrcode || null;
    } catch (error) {
      console.error('Error getting instance QR code:', error);
      return null;
    }
  }

  async getInstanceConnectionStatus(instanceId: string): Promise<'connected' | 'disconnected' | 'connecting'> {
    try {
      const instance = await this.repository.getById(instanceId);
      
      if (!instance) {
        throw new Error(`Instance with ID ${instanceId} not found`);
      }

      // Fazer a requisição para a API Evolution para obter o status da conexão
      const response = await fetch(`${instance.base_url}/instance/status`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'apikey': instance.api_key
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get connection status: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.status === 'connected') {
        return 'connected';
      } else if (data.status === 'connecting') {
        return 'connecting';
      } else {
        return 'disconnected';
      }
    } catch (error) {
      console.error('Error getting instance connection status:', error);
      return 'disconnected';
    }
  }

  async getInstanceWithConnectionDetails(instanceId: string): Promise<ApiInstanceWithConnection | null> {
    try {
      const instance = await this.repository.getById(instanceId);
      
      if (!instance) {
        return null;
      }

      const connectionStatus = await this.getInstanceConnectionStatus(instanceId);
      let qrCode = null;
      
      if (connectionStatus !== 'connected') {
        qrCode = await this.getInstanceQRCode(instanceId);
      }

      return {
        ...instance,
        connection_status: connectionStatus,
        qr_code: qrCode
      };
    } catch (error) {
      console.error('Error getting instance with connection details:', error);
      return null;
    }
  }
}

