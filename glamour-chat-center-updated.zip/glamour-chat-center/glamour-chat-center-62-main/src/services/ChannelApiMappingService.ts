import { ChannelApiMapping } from '../types/domain/api/ChannelApiMapping';
import { ChannelApiMappingRepository } from '../repositories/ChannelApiMappingRepository';
import { ApiInstanceRepository } from '../repositories/ApiInstanceRepository';
import { ApiInstance } from '../types/domain/api/ApiInstance';

export class ChannelApiMappingService {
  private repository: ChannelApiMappingRepository;
  private apiInstanceRepository: ApiInstanceRepository;

  constructor() {
    this.repository = new ChannelApiMappingRepository();
    this.apiInstanceRepository = new ApiInstanceRepository();
  }

  async getAllMappings(): Promise<ChannelApiMapping[]> {
    return this.repository.getAll();
  }

  async getMappingByChannelId(channelId: string): Promise<ChannelApiMapping | null> {
    return this.repository.getByChannelId(channelId);
  }

  async getApiInstanceForChannel(channelId: string): Promise<ApiInstance | null> {
    try {
      const mapping = await this.repository.getByChannelId(channelId);
      
      if (!mapping) {
        return null;
      }

      return this.apiInstanceRepository.getById(mapping.api_instance_id);
    } catch (error) {
      console.error(`Error getting API instance for channel ${channelId}:`, error);
      return null;
    }
  }

  async createMapping(mapping: ChannelApiMapping): Promise<ChannelApiMapping> {
    return this.repository.create(mapping);
  }

  async updateMapping(id: string, mapping: Partial<ChannelApiMapping>): Promise<ChannelApiMapping> {
    return this.repository.update(id, mapping);
  }

  async upsertMapping(channelId: string, apiInstanceId: string): Promise<ChannelApiMapping> {
    return this.repository.upsertByChannelId(channelId, apiInstanceId);
  }

  async deleteMapping(id: string): Promise<void> {
    return this.repository.delete(id);
  }

  async deleteMappingByChannelId(channelId: string): Promise<void> {
    return this.repository.deleteByChannelId(channelId);
  }
}

