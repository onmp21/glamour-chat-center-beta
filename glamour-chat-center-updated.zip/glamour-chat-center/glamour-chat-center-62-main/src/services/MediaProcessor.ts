export interface MediaResult {
  type: 'audio' | 'image' | 'video' | 'document' | 'text' | 'placeholder';
  url: string;
  isProcessed: boolean;
  error?: string;
  size?: string;
  mimeType?: string;
}

export class MediaProcessor {
  static process(content: string, messageType: string): MediaResult {
    console.log('🎯 [MEDIA_PROCESSOR] Processing:', { messageType, contentLength: content.length });
    
    // Se já é data URL, retornar diretamente
    if (content.startsWith('data:')) {
      console.log('✅ [MEDIA_PROCESSOR] Already data URL');
      return this.handleDataUrl(content, messageType);
    }

    // Detectar placeholder text primeiro
    if (this.isPlaceholderText(content)) {
      console.log('📝 [MEDIA_PROCESSOR] Placeholder detected');
      return {
        type: 'placeholder',
        url: content,
        isProcessed: false
      };
    }

    // Para tipos de mídia, tentar detectar se é base64 puro
    if (this.isMediaType(messageType) && this.looksLikeBase64(content)) {
      console.log('🔄 [MEDIA_PROCESSOR] Converting base64 for:', messageType);
      return this.convertBase64ToDataUrl(content, messageType);
    }
    
    // Verificar se é base64 mesmo para tipos não-mídia
    // Isso permite processar base64 independentemente do tipo de mensagem declarado
    if (this.looksLikeBase64(content)) {
      console.log('🔍 [MEDIA_PROCESSOR] Detected base64 content despite message type:', messageType);
      // Tentar detectar o tipo de mídia a partir do conteúdo
      const detectedType = this.detectMediaTypeFromBase64(content);
      if (detectedType !== 'unknown') {
        console.log('🔄 [MEDIA_PROCESSOR] Auto-detected media type from base64:', detectedType);
        return this.convertBase64ToDataUrl(content, detectedType);
      }
    }

    // Caso contrário, tratar como texto
    console.log('📝 [MEDIA_PROCESSOR] Treating as text');
    return {
      type: 'text',
      url: content,
      isProcessed: false
    };
  }

  private static isMediaType(messageType: string): boolean {
    const mediaTypes = ['audio', 'image', 'video', 'document', 'mensagem_de_audio', 'mensagem_de_imagem', 'mensagem_de_video'];
    return mediaTypes.includes(messageType.toLowerCase());
  }

  private static looksLikeBase64(content: string): boolean {
    // Verificar se parece com base64
    if (content.length < 50) return false;
    
    // Remover espaços e quebras de linha
    const cleaned = content.replace(/\s/g, '');
    
    // Verificar se contém apenas caracteres base64
    const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
    
    // Verificar se pelo menos 90% dos caracteres são válidos para base64
    // Isso permite alguma tolerância para caracteres inválidos
    const validChars = cleaned.replace(/[^A-Za-z0-9+/=]/g, '');
    const validRatio = validChars.length / cleaned.length;
    
    // Melhorar a detecção: verificar se tem características típicas de base64
    const hasTypicalBase64Length = cleaned.length % 4 === 0 || (cleaned.length + 1) % 4 === 0 || (cleaned.length + 2) % 4 === 0;
    const hasBase64Chars = /[A-Za-z0-9+/]/.test(cleaned);
    const hasValidEnding = cleaned.endsWith('=') || cleaned.endsWith('==') || /[A-Za-z0-9+/]$/.test(cleaned);
    
    return (base64Regex.test(cleaned) || (validRatio > 0.9 && cleaned.length > 100)) && 
           hasTypicalBase64Length && hasBase64Chars && hasValidEnding;
  }

  private static detectMediaTypeFromBase64(content: string): string {
    // Remover espaços e quebras de linha
    const cleaned = content.replace(/\s/g, '');
    
    try {
      // Tentar decodificar os primeiros bytes para verificar assinaturas
      const firstBytes = cleaned.substring(0, 20);
      
      // Verificar assinaturas comuns em base64
      // JPEG: /9j/
      if (cleaned.startsWith('/9j/') || cleaned.startsWith('iVBOR')) return 'image';
      
      // PNG: iVBOR
      if (cleaned.startsWith('iVBOR')) return 'image';
      
      // PDF: JVBERi
      if (cleaned.startsWith('JVBERi')) return 'document';
      
      // MP3/Audio: SUQz ou ID3 ou //uQ
      if (cleaned.startsWith('SUQz') || cleaned.startsWith('//uQ') || cleaned.startsWith('ID3')) return 'audio';
      
      // MP4/Video: AAAAGG ou AAAAHG ou AAAAFG
      if (cleaned.startsWith('AAAAGG') || cleaned.startsWith('AAAAHG') || cleaned.startsWith('AAAAFG')) return 'video';
      
      // WebP: UklGR
      if (cleaned.startsWith('UklGR')) return 'image';
      
      // GIF: R0lGO
      if (cleaned.startsWith('R0lGO')) return 'image';
      
      // OGG Audio: T2dn
      if (cleaned.startsWith('T2dn')) return 'audio';
      
      // WAV Audio: UklGR (diferente do WebP pelo contexto)
      if (cleaned.startsWith('UklGR') && cleaned.length > 1000) return 'audio';
      
      // Se não conseguiu detectar pela assinatura, usar heurísticas de tamanho
      // Áudios curtos (mensagens de voz) tendem a ser menores
      if (cleaned.length < 100000) return 'audio';
      // Imagens tendem a ser de tamanho médio
      if (cleaned.length < 500000) return 'image';
      // Vídeos tendem a ser maiores
      if (cleaned.length > 500000) return 'video';
      
    } catch (error) {
      console.warn('🔍 [MEDIA_PROCESSOR] Error detecting media type from base64:', error);
    }
    
    return 'unknown';
  }

  private static convertBase64ToDataUrl(content: string, messageType: string): MediaResult {
    try {
      // Limpar o conteúdo - remover espaços, quebras de linha e caracteres inválidos
      let cleanBase64 = content.replace(/\s/g, '');
      
      // Remover caracteres inválidos para base64
      cleanBase64 = cleanBase64.replace(/[^A-Za-z0-9+/=]/g, '');
      
      // Garantir que o comprimento seja múltiplo de 4 (requisito do base64)
      while (cleanBase64.length % 4 !== 0) {
        cleanBase64 += '=';
      }
      
      // Validar se o base64 é válido tentando decodificar uma pequena parte
      try {
        const testDecode = atob(cleanBase64.substring(0, Math.min(100, cleanBase64.length)));
        if (!testDecode) {
          throw new Error('Invalid base64 content');
        }
      } catch (decodeError) {
        console.error('❌ [MEDIA_PROCESSOR] Invalid base64 content:', decodeError);
        return {
          type: 'placeholder',
          url: `[Erro: Conteúdo base64 inválido]`,
          isProcessed: false,
          error: 'Invalid base64'
        };
      }
      
      // Determinar MIME type
      const mimeType = this.getMimeTypeFromMessageType(messageType);
      const mediaType = this.getMediaTypeFromMessageType(messageType);
      
      // Criar data URL
      const dataUrl = `data:${mimeType};base64,${cleanBase64}`;
      
      console.log('✅ [MEDIA_PROCESSOR] Base64 converted successfully');
      
      return {
        type: mediaType,
        url: dataUrl,
        isProcessed: true,
        mimeType,
        size: this.estimateSize(cleanBase64)
      };
    } catch (error) {
      console.error('❌ [MEDIA_PROCESSOR] Conversion error:', error);
      return {
        type: 'placeholder',
        url: `[Erro ao carregar ${messageType}]`,
        isProcessed: false,
        error: 'Conversion failed'
      };
    }
  }

  private static handleDataUrl(dataUrl: string, messageType: string): MediaResult {
    const mimeMatch = dataUrl.match(/data:([^;]+)/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'unknown';
    const mediaType = this.getMediaTypeFromMessageType(messageType);
    
    return {
      type: mediaType,
      url: dataUrl,
      isProcessed: false,
      mimeType,
      size: this.estimateSize(dataUrl.split(',')[1] || '')
    };
  }

  private static getMediaTypeFromMessageType(messageType: string): 'audio' | 'image' | 'video' | 'document' | 'text' {
    const type = messageType.toLowerCase();
    if (type.includes('audio')) return 'audio';
    if (type.includes('image') || type.includes('imagem')) return 'image';
    if (type.includes('video')) return 'video';
    if (type.includes('document') || type.includes('file')) return 'document';
    return 'text';
  }

  private static getMimeTypeFromMessageType(messageType: string): string {
    const type = messageType.toLowerCase();
    if (type.includes('audio')) return 'audio/mpeg';
    if (type.includes('image') || type.includes('imagem')) return 'image/jpeg';
    if (type.includes('video')) return 'video/mp4';
    if (type.includes('document') || type.includes('file')) return 'application/pdf';
    return 'application/octet-stream';
  }

  private static isPlaceholderText(content: string): boolean {
    const placeholderPatterns = [
      /^[Áudio]$/i,
      /^[Imagem]$/i,
      /^[Vídeo]$/i,
      /^[Documento.*]$/i,
      /^Mensagem de áudio$/i,
      /^Mensagem de imagem$/i,
      /^Mensagem de vídeo$/i,
      /^[Mídia]$/i,
      /^\[Audio\]$/i,
      /^\[Image\]$/i,
      /^\[Video\]$/i,
      /^\[Document.*\]$/i
    ];
    
    return placeholderPatterns.some(pattern => pattern.test(content.trim()));
  }

  private static estimateSize(base64: string): string {
    if (!base64) return '0 B';
    const bytes = (base64.length * 3) / 4;
    if (bytes < 1024) return `${bytes.toFixed(0)} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  static getMediaIcon(type: string): string {
    const icons = {
      audio: '🎵',
      image: '🖼️',
      video: '🎬',
      document: '📎',
      placeholder: '📄',
      text: '📝'
    };
    return icons[type as keyof typeof icons] || '📄';
  }

  // Método adicional para validar e limpar base64 antes do envio
  static validateAndCleanBase64(base64Content: string): { isValid: boolean; cleanedContent: string; error?: string } {
    try {
      // Remover prefixo data URL se presente
      let cleaned = base64Content;
      if (cleaned.startsWith('data:')) {
        const parts = cleaned.split(',');
        if (parts.length > 1) {
          cleaned = parts[1];
        }
      }
      
      // Remover espaços e quebras de linha
      cleaned = cleaned.replace(/\s/g, '');
      
      // Remover caracteres inválidos
      cleaned = cleaned.replace(/[^A-Za-z0-9+/=]/g, '');
      
      // Garantir padding correto
      while (cleaned.length % 4 !== 0) {
        cleaned += '=';
      }
      
      // Testar decodificação
      const testDecode = atob(cleaned.substring(0, Math.min(100, cleaned.length)));
      
      return {
        isValid: true,
        cleanedContent: cleaned
      };
    } catch (error) {
      return {
        isValid: false,
        cleanedContent: '',
        error: error.message
      };
    }
  }
}

