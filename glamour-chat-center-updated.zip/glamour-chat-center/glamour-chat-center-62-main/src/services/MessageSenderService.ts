import { supabase } from '../integrations/supabase/client';
import { ChannelApiMappingService } from './ChannelApiMappingService';

export class MessageSenderService {
  private channelApiMappingService: ChannelApiMappingService;

  constructor() {
    this.channelApiMappingService = new ChannelApiMappingService();
  }

  async sendTextMessage(channelId: string, to: string, text: string): Promise<boolean> {
    try {
      // Obter a instância da API para o canal
      const apiInstance = await this.channelApiMappingService.getApiInstanceForChannel(channelId);
      
      if (!apiInstance) {
        console.error(`Nenhuma instância da API configurada para o canal ${channelId}`);
        return false;
      }

      // Enviar mensagem usando a API Evolution
      const response = await fetch(`${apiInstance.base_url}/message/text`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': apiInstance.api_key
        },
        body: JSON.stringify({
          number: to,
          options: {
            delay: 1200
          },
          textMessage: {
            text
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Falha ao enviar mensagem: ${response.statusText}`);
      }

      // Registrar mensagem enviada no banco de dados
      const { error } = await supabase
        .from('messages')
        .insert([
          {
            channel_id: channelId,
            session_id: to,
            content: text,
            direction: 'outgoing',
            message_type: 'text',
            status: 'sent'
          }
        ]);

      if (error) {
        console.error('Erro ao registrar mensagem enviada:', error);
      }

      return true;
    } catch (error) {
      console.error('Erro ao enviar mensagem de texto:', error);
      return false;
    }
  }

  async sendMediaMessage(channelId: string, to: string, mediaUrl: string, caption: string, mediaType: 'image' | 'audio' | 'video' | 'document'): Promise<boolean> {
    try {
      // Obter a instância da API para o canal
      const apiInstance = await this.channelApiMappingService.getApiInstanceForChannel(channelId);
      
      if (!apiInstance) {
        console.error(`Nenhuma instância da API configurada para o canal ${channelId}`);
        return false;
      }

      // Determinar o endpoint com base no tipo de mídia
      let endpoint = '';
      switch (mediaType) {
        case 'image':
          endpoint = '/message/image';
          break;
        case 'audio':
          endpoint = '/message/audio';
          break;
        case 'video':
          endpoint = '/message/video';
          break;
        case 'document':
          endpoint = '/message/document';
          break;
        default:
          throw new Error(`Tipo de mídia não suportado: ${mediaType}`);
      }

      // Enviar mensagem usando a API Evolution
      const response = await fetch(`${apiInstance.base_url}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': apiInstance.api_key
        },
        body: JSON.stringify({
          number: to,
          options: {
            delay: 1200
          },
          [mediaType]: {
            url: mediaUrl,
            caption
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Falha ao enviar mensagem de mídia: ${response.statusText}`);
      }

      // Registrar mensagem enviada no banco de dados
      const { error } = await supabase
        .from('messages')
        .insert([
          {
            channel_id: channelId,
            session_id: to,
            content: caption,
            media_url: mediaUrl,
            direction: 'outgoing',
            message_type: mediaType,
            status: 'sent'
          }
        ]);

      if (error) {
        console.error('Erro ao registrar mensagem de mídia enviada:', error);
      }

      return true;
    } catch (error) {
      console.error(`Erro ao enviar mensagem de ${mediaType}:`, error);
      return false;
    }
  }
}

