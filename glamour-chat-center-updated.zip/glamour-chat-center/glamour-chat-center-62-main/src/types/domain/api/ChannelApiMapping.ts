export interface ChannelApiMapping {
  id?: string;
  channel_id: string;
  api_instance_id: string;
  created_at?: string;
  updated_at?: string;
}

