import { supabase } from '../integrations/supabase/client';
import { ApiInstance } from '../types/domain/api/ApiInstance';
import { BaseRepository } from './BaseRepository';

export class ApiInstanceRepository extends BaseRepository<ApiInstance> {
  constructor() {
    super('api_instances');
  }

  async getAll(): Promise<ApiInstance[]> {
    const { data, error } = await supabase
      .from(this.tableName)
      .select('*')
      .order('instance_name', { ascending: true });

    if (error) {
      console.error('Error fetching API instances:', error);
      throw new Error(`Failed to fetch API instances: ${error.message}`);
    }

    return data || [];
  }

  async getById(id: string): Promise<ApiInstance | null> {
    const { data, error } = await supabase
      .from(this.tableName)
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error(`Error fetching API instance with ID ${id}:`, error);
      throw new Error(`Failed to fetch API instance: ${error.message}`);
    }

    return data;
  }

  async create(instance: ApiInstance): Promise<ApiInstance> {
    const { data, error } = await supabase
      .from(this.tableName)
      .insert([instance])
      .select()
      .single();

    if (error) {
      console.error('Error creating API instance:', error);
      throw new Error(`Failed to create API instance: ${error.message}`);
    }

    return data;
  }

  async update(id: string, instance: Partial<ApiInstance>): Promise<ApiInstance> {
    const { data, error } = await supabase
      .from(this.tableName)
      .update(instance)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error(`Error updating API instance with ID ${id}:`, error);
      throw new Error(`Failed to update API instance: ${error.message}`);
    }

    return data;
  }

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from(this.tableName)
      .delete()
      .eq('id', id);

    if (error) {
      console.error(`Error deleting API instance with ID ${id}:`, error);
      throw new Error(`Failed to delete API instance: ${error.message}`);
    }
  }
}

