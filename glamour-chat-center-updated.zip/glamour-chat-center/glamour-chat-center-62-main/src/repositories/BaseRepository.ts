
import { supabase } from '@/integrations/supabase/client';
import { TableName } from '@/utils/channelMapping';
import { RealtimeChannel } from '@supabase/supabase-js';

export abstract class BaseRepository<T = any> {
  protected tableName: TableName;
  private static activeChannels = new Map<string, RealtimeChannel>();

  constructor(tableName: TableName) {
    this.tableName = tableName;
  }

  get table(): TableName {
    return this.tableName;
  }

  // Getter público para acessar o nome da tabela
  get tableNamePublic(): TableName {
    return this.tableName;
  }

  async findAll(): Promise<T[]> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .order('id', { ascending: true });

      if (error) {
        console.error(`❌ [REPOSITORY] Error fetching from ${this.tableName}:`, error);
        throw error;
      }

      return (data || []) as T[];
    } catch (err) {
      console.error(`❌ [REPOSITORY] Failed to fetch from ${this.tableName}:`, err);
      throw err;
    }
  }

  async findBySessionId(sessionId: string): Promise<T[]> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('session_id', sessionId)
        .order('id', { ascending: true });

      if (error) {
        console.error(`❌ [REPOSITORY] Error fetching by session_id from ${this.tableName}:`, error);
        throw error;
      }

      return (data || []) as T[];
    } catch (err) {
      console.error(`❌ [REPOSITORY] Failed to fetch by session_id from ${this.tableName}:`, err);
      throw err;
    }
  }

  async create(data: any): Promise<T> {
    try {
      const { data: result, error } = await supabase
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) {
        console.error(`❌ [REPOSITORY] Error inserting into ${this.tableName}:`, error);
        throw error;
      }

      return result as T;
    } catch (err) {
      console.error(`❌ [REPOSITORY] Failed to insert into ${this.tableName}:`, err);
      throw err;
    }
  }

  async update(id: number, data: any): Promise<T> {
    try {
      const { data: result, error } = await supabase
        .from(this.tableName)
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error(`❌ [REPOSITORY] Error updating ${this.tableName}:`, error);
        throw error;
      }

      return result as T;
    } catch (err) {
      console.error(`❌ [REPOSITORY] Failed to update ${this.tableName}:`, err);
      throw err;
    }
  }

  async delete(id: number): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) {
        console.error(`❌ [REPOSITORY] Error deleting from ${this.tableName}:`, error);
        throw error;
      }
    } catch (err) {
      console.error(`❌ [REPOSITORY] Failed to delete from ${this.tableName}:`, err);
      throw err;
    }
  }

  createRealtimeChannel(channelSuffix: string = ''): RealtimeChannel {
    const channelName = `realtime-${this.tableName}${channelSuffix}`;
    
    // Check if channel already exists and clean it up
    if (BaseRepository.activeChannels.has(channelName)) {
      const existingChannel = BaseRepository.activeChannels.get(channelName);
      if (existingChannel) {
        console.log(`🧹 [REPOSITORY] Cleaning up existing channel: ${channelName}`);
        existingChannel.unsubscribe();
        BaseRepository.activeChannels.delete(channelName);
      }
    }
    
    console.log(`🔴 [REPOSITORY] Creating new realtime channel: ${channelName}`);
    const channel = supabase.channel(channelName);
    
    // Store the channel reference
    BaseRepository.activeChannels.set(channelName, channel);
    
    return channel;
  }

  static cleanupChannel(channelName: string): void {
    if (BaseRepository.activeChannels.has(channelName)) {
      const channel = BaseRepository.activeChannels.get(channelName);
      if (channel) {
        console.log(`🧹 [REPOSITORY] Manual cleanup of channel: ${channelName}`);
        channel.unsubscribe();
        BaseRepository.activeChannels.delete(channelName);
      }
    }
  }

  static cleanupAllChannels(): void {
    console.log(`🧹 [REPOSITORY] Cleaning up all ${BaseRepository.activeChannels.size} active channels`);
    BaseRepository.activeChannels.forEach((channel, name) => {
      channel.unsubscribe();
    });
    BaseRepository.activeChannels.clear();
  }
}
