import { supabase } from '../integrations/supabase/client';
import { ChannelApiMapping } from '../types/domain/api/ChannelApiMapping';
import { BaseRepository } from './BaseRepository';

export class ChannelApiMappingRepository extends BaseRepository<ChannelApiMapping> {
  constructor() {
    super('channel_api_mappings');
  }

  async getAll(): Promise<ChannelApiMapping[]> {
    const { data, error } = await supabase
      .from(this.tableName)
      .select('*');

    if (error) {
      console.error('Error fetching channel API mappings:', error);
      throw new Error(`Failed to fetch channel API mappings: ${error.message}`);
    }

    return data || [];
  }

  async getByChannelId(channelId: string): Promise<ChannelApiMapping | null> {
    const { data, error } = await supabase
      .from(this.tableName)
      .select('*')
      .eq('channel_id', channelId)
      .single();

    if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned" error
      console.error(`Error fetching channel API mapping for channel ${channelId}:`, error);
      throw new Error(`Failed to fetch channel API mapping: ${error.message}`);
    }

    return data || null;
  }

  async create(mapping: ChannelApiMapping): Promise<ChannelApiMapping> {
    const { data, error } = await supabase
      .from(this.tableName)
      .insert([mapping])
      .select()
      .single();

    if (error) {
      console.error('Error creating channel API mapping:', error);
      throw new Error(`Failed to create channel API mapping: ${error.message}`);
    }

    return data;
  }

  async update(id: string, mapping: Partial<ChannelApiMapping>): Promise<ChannelApiMapping> {
    const { data, error } = await supabase
      .from(this.tableName)
      .update(mapping)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error(`Error updating channel API mapping with ID ${id}:`, error);
      throw new Error(`Failed to update channel API mapping: ${error.message}`);
    }

    return data;
  }

  async upsertByChannelId(channelId: string, apiInstanceId: string): Promise<ChannelApiMapping> {
    // Check if mapping exists
    const existingMapping = await this.getByChannelId(channelId);
    
    if (existingMapping) {
      // Update existing mapping
      const { data, error } = await supabase
        .from(this.tableName)
        .update({ api_instance_id: apiInstanceId })
        .eq('channel_id', channelId)
        .select()
        .single();

      if (error) {
        console.error(`Error updating channel API mapping for channel ${channelId}:`, error);
        throw new Error(`Failed to update channel API mapping: ${error.message}`);
      }

      return data;
    } else {
      // Create new mapping
      const { data, error } = await supabase
        .from(this.tableName)
        .insert([{ channel_id: channelId, api_instance_id: apiInstanceId }])
        .select()
        .single();

      if (error) {
        console.error(`Error creating channel API mapping for channel ${channelId}:`, error);
        throw new Error(`Failed to create channel API mapping: ${error.message}`);
      }

      return data;
    }
  }

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from(this.tableName)
      .delete()
      .eq('id', id);

    if (error) {
      console.error(`Error deleting channel API mapping with ID ${id}:`, error);
      throw new Error(`Failed to delete channel API mapping: ${error.message}`);
    }
  }

  async deleteByChannelId(channelId: string): Promise<void> {
    const { error } = await supabase
      .from(this.tableName)
      .delete()
      .eq('channel_id', channelId);

    if (error) {
      console.error(`Error deleting channel API mapping for channel ${channelId}:`, error);
      throw new Error(`Failed to delete channel API mapping: ${error.message}`);
    }
  }
}

