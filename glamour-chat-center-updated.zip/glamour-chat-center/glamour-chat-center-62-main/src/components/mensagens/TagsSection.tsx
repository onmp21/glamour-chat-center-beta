
import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Search, Trash2, Tag } from 'lucide-react';
import { useTags } from '@/hooks/useTags';

interface TagsSectionProps {
  isDarkMode: boolean;
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

export const TagsSection: React.FC<TagsSectionProps> = ({
  isDarkMode,
  searchTerm,
  onSearchChange
}) => {
  const { tags, loading, createTag, deleteTag } = useTags();
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#b5103c');

  const handleCreateTag = async () => {
    if (!newTagName.trim()) return;
    
    const success = await createTag(newTagName.trim(), newTagColor);
    if (success) {
      setNewTagName('');
      setNewTagColor('#b5103c');
    }
  };

  const handleDeleteTag = async (tagId: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta tag?')) {
      await deleteTag(tagId);
    }
  };

  const filteredTags = tags.filter(tag =>
    tag.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Tags predefinidas focadas em atendimento
  const predefinedTags = [
    { name: 'Urgente', color: '#dc2626', description: 'Atendimentos que precisam de resposta imediata' },
    { name: 'Agendamento', color: '#ea580c', description: 'Solicitações de marcação de horários' },
    { name: 'Exames', color: '#b5103c', description: 'Conversas sobre exames oftalmológicos' },
    { name: 'Consultas', color: '#7c3aed', description: 'Marcação e informações sobre consultas' },
    { name: 'Informações', color: '#059669', description: 'Pedidos de informações gerais' },
    { name: 'Suporte', color: '#0ea5e9', description: 'Problemas técnicos ou dúvidas' },
    { name: 'Feedback', color: '#8b5cf6', description: 'Elogios, críticas ou sugestões' },
    { name: 'Seguimento', color: '#f59e0b', description: 'Casos que precisam de acompanhamento' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#b5103c]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Busca */}
      <Card className={cn(
        "border",
        isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
      )}>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#b5103c]" />
            <Input
              placeholder="Buscar tags..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className={cn(
                "pl-10",
                isDarkMode ? "bg-[#27272a] border-[#3f3f46]" : "bg-white border-gray-200"
              )}
            />
          </div>
        </CardContent>
      </Card>

      {/* Criar nova tag */}
      <Card className={cn(
        "border",
        isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
      )}>
        <CardHeader>
          <CardTitle className={cn(
            "text-lg font-semibold flex items-center gap-2",
            isDarkMode ? "text-white" : "text-gray-900"
          )}>
            <Tag size={20} className="text-[#b5103c]" />
            Criar Nova Tag
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Nome da tag..."
              value={newTagName}
              onChange={(e) => setNewTagName(e.target.value)}
              className={cn(
                "flex-1",
                isDarkMode ? "bg-[#27272a] border-[#3f3f46]" : "bg-white border-gray-200"
              )}
              onKeyPress={(e) => e.key === 'Enter' && handleCreateTag()}
            />
            <input
              type="color"
              value={newTagColor}
              onChange={(e) => setNewTagColor(e.target.value)}
              className="w-12 h-10 rounded border cursor-pointer"
              title="Escolher cor"
            />
            <Button
              onClick={handleCreateTag}
              disabled={!newTagName.trim()}
              className="bg-[#b5103c] hover:bg-[#9d0e34] text-white"
            >
              <Plus size={16} />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tags sugeridas para atendimento */}
      <Card className={cn(
        "border",
        isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
      )}>
        <CardHeader>
          <CardTitle className={cn(
            "text-lg font-semibold",
            isDarkMode ? "text-white" : "text-gray-900"
          )}>
            Tags Sugeridas para Atendimento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {predefinedTags.map((tag) => {
              const exists = tags.some(t => t.name === tag.name);
              return (
                <div
                  key={tag.name}
                  className={cn(
                    "p-3 rounded-lg border",
                    isDarkMode ? "bg-[#27272a] border-[#3f3f46]" : "bg-gray-50 border-gray-200"
                  )}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Badge
                      style={{ backgroundColor: tag.color }}
                      className="text-white"
                    >
                      {tag.name}
                    </Badge>
                    {!exists && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => createTag(tag.name, tag.color)}
                        className="h-6 px-2 text-xs"
                      >
                        <Plus size={12} className="mr-1" />
                        Criar
                      </Button>
                    )}
                    {exists && (
                      <span className={cn(
                        "text-xs px-2 py-1 rounded",
                        isDarkMode ? "bg-green-900 text-green-300" : "bg-green-100 text-green-700"
                      )}>
                        Criada
                      </span>
                    )}
                  </div>
                  <p className={cn(
                    "text-xs",
                    isDarkMode ? "text-gray-400" : "text-gray-600"
                  )}>
                    {tag.description}
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Tags existentes */}
      <Card className={cn(
        "border",
        isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
      )}>
        <CardHeader>
          <CardTitle className={cn(
            "text-lg font-semibold",
            isDarkMode ? "text-white" : "text-gray-900"
          )}>
            Minhas Tags ({filteredTags.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredTags.length === 0 ? (
            <div className="text-center py-8">
              <Tag className={cn(
                "mx-auto mb-4",
                isDarkMode ? "text-gray-500" : "text-gray-400"
              )} size={48} />
              <p className={cn(
                "text-center",
                isDarkMode ? "text-gray-400" : "text-gray-600"
              )}>
                {searchTerm ? 'Nenhuma tag encontrada' : 'Nenhuma tag criada ainda'}
              </p>
              {!searchTerm && (
                <p className={cn(
                  "text-sm mt-2",
                  isDarkMode ? "text-gray-500" : "text-gray-500"
                )}>
                  Crie tags para organizar melhor os atendimentos
                </p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredTags.map((tag) => (
                <div
                  key={tag.id}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-lg border",
                    isDarkMode ? "bg-[#27272a] border-[#3f3f46]" : "bg-gray-50 border-gray-200"
                  )}
                >
                  <Badge
                    style={{ backgroundColor: tag.color }}
                    className="text-white"
                  >
                    {tag.name}
                  </Badge>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDeleteTag(tag.id)}
                    className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
