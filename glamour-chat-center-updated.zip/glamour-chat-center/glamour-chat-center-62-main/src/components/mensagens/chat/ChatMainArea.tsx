import React, { useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Menu, MoreVertical } from 'lucide-react';
import { ConversationHeader } from '../ConversationHeader';
import { ChatInput } from '../ChatInput';
import { AndressaMessageDisplay } from '@/components/chat/AndressaMessageDisplay';
import { YelenaMessageDisplay } from '@/components/chat/YelenaMessageDisplay';

interface Message {
  id: string;
  content: string;
  timestamp: string;
  sender: 'customer' | 'agent';
  tipo_remetente?: string;
  type: 'text' | 'image' | 'audio' | 'video' | 'document';
  fileUrl?: string;
  fileName?: string;
  read: boolean;
  Nome_do_contato?: string;
  mensagemtype?: string;
}

interface Conversation {
  contactName: string;
  contactNumber: string;
}

interface ChatMainAreaProps {
  selectedConv: any;
  conversationForHeader: Conversation | null;
  displayMessages: Message[];
  messagesLoading: boolean;
  isSidebarOpen: boolean;
  isDarkMode: boolean;
  channelId?: string;
  onSidebarToggle: (open: boolean) => void;
  onMarkAsResolved: () => void;
  onSendMessage: (message: string) => void;
}

export const ChatMainArea: React.FC<ChatMainAreaProps> = ({
  selectedConv,
  conversationForHeader,
  displayMessages,
  messagesLoading,
  isSidebarOpen,
  isDarkMode,
  channelId,
  onSidebarToggle,
  onMarkAsResolved,
  onSendMessage
}) => {
  // Referência para o contêiner de mensagens
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  // Função para rolar para o final das mensagens
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  // Rolar para o final quando as mensagens mudarem ou quando a conversa for selecionada
  useEffect(() => {
    if (!messagesLoading) {
      // Pequeno atraso para garantir que o DOM foi atualizado
      const timeoutId = setTimeout(() => {
        scrollToBottom();
      }, 100);
      
      return () => clearTimeout(timeoutId);
    }
  }, [displayMessages, messagesLoading, selectedConv]);

  if (!selectedConv || !conversationForHeader) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <p className={cn("text-gray-500", isDarkMode ? "text-gray-400" : "text-gray-600")}>
          Selecione uma conversa para começar
        </p>
      </div>
    );
  }

  const handleMenuClick = () => {
    console.log('⋮ Menu button clicked');
    alert('Menu de opções em desenvolvimento');
  };

  const renderMessage = (message: Message) => {
    console.log(`🎭 [CHAT_MAIN_AREA] Rendering message for channel: ${channelId}`);
    
    // Usar AndressaMessageDisplay para canal Andressa (gerente-externo)
    if (channelId === 'gerente-externo' || channelId === 'd2892900-ca8f-4b08-a73f-6b7aa5866ff7') {
      console.log(`🔴 [CHAT_MAIN_AREA] Using AndressaMessageDisplay for channel: ${channelId}`);
      return (
        <AndressaMessageDisplay
          key={message.id}
          message={{
            id: message.id,
            content: message.content,
            timestamp: message.timestamp,
            sender: message.sender,
            tipo_remetente: message.tipo_remetente,
            Nome_do_contato: message.Nome_do_contato,
            mensagemtype: message.mensagemtype
          }}
          isDarkMode={isDarkMode}
        />
      );
    }

    // Usar YelenaMessageDisplay para canal Yelena
    if (channelId === 'chat' || channelId === 'af1e5797-edc6-4ba3-a57a-25cf7297c4d6') {
      console.log(`🟢 [CHAT_MAIN_AREA] Using YelenaMessageDisplay for channel: ${channelId}`);
      return (
        <YelenaMessageDisplay
          key={message.id}
          message={{
            id: message.id,
            content: message.content,
            timestamp: message.timestamp,
            sender: message.sender,
            tipo_remetente: message.tipo_remetente,
            Nome_do_contato: message.Nome_do_contato,
            mensagemtype: message.mensagemtype
          }}
          isDarkMode={isDarkMode}
        />
      );
    }

    // Renderização genérica para outros canais
    console.log(`⚪ [CHAT_MAIN_AREA] Using generic display for channel: ${channelId}`);
    const isAgentMessage = message.sender === 'agent';
    
    return (
      <div
        key={message.id}
        className={cn(
          "flex",
          isAgentMessage ? "justify-end" : "justify-start"
        )}
      >
        <div
          className={cn(
            "max-w-[70%] rounded-lg p-3",
            isAgentMessage
              ? "bg-[#e57a96] text-white" // Cor mais clara para balões vermelhos
              : isDarkMode
                ? "bg-[#2a2a2a] text-white border border-[#3f3f46]"
                : "bg-gray-100 text-gray-900 border border-gray-200"
          )}
        >
          <p className="text-sm">{message.content}</p>
          <div className="flex items-center justify-between mt-1">
            <span className={cn(
              "text-xs",
              isAgentMessage ? "text-gray-200" : isDarkMode ? "text-gray-400" : "text-gray-600"
            )}>
              {new Date(message.timestamp).toLocaleTimeString('pt-BR', {
                hour: '2-digit',
                minute: '2-digit'
              })}
            </span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Header */}
      <div className={cn(
        "flex items-center border-b",
        isDarkMode ? "border-[#3f3f46] bg-[#18181b]" : "border-gray-200 bg-white"
      )}>
        {!isSidebarOpen && (
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onSidebarToggle(true)}
            className="ml-2"
          >
            <Menu size={20} />
          </Button>
        )}
        <div className="flex-1">
          <ConversationHeader
            conversation={conversationForHeader}
            isDarkMode={isDarkMode}
            onMarkAsResolved={onMarkAsResolved}
          />
        </div>
        <div className="flex items-center gap-2 pr-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onMarkAsResolved}
            className={cn(
              "flex items-center gap-2",
              isDarkMode ? "border-[#3f3f46] hover:bg-[#27272a]" : "border-gray-200 hover:bg-gray-50"
            )}
          >
            Resolver
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={handleMenuClick}
            className={cn(
              isDarkMode ? "hover:bg-[#27272a]" : "hover:bg-gray-50"
            )}
          >
            <MoreVertical size={18} />
          </Button>
        </div>
      </div>
      
      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        {messagesLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#b5103c]"></div>
          </div>
        ) : (
          <div className="space-y-4">
            {displayMessages.map(renderMessage)}
            {/* Elemento invisível no final para rolar até ele */}
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>
      
      {/* Input */}
      <ChatInput 
        isDarkMode={isDarkMode} 
        onSendMessage={(message) => {
          onSendMessage(message);
          // Rolar para o final após enviar uma mensagem
          setTimeout(scrollToBottom, 300);
        }}
      />
    </>
  );
};

