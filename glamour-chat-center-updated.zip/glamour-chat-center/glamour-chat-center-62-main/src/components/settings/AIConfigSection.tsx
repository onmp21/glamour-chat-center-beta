import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Key, Lock, Shield, Check, AlertCircle, Sparkles, Brain, Bot, Settings } from 'lucide-react';
import { ChatGPTService } from '@/services/ChatGPTService';

interface AIConfigSectionProps {
  isDarkMode: boolean;
}

export const AIConfigSection: React.FC<AIConfigSectionProps> = ({ isDarkMode }) => {
  const { toast } = useToast();
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gpt-3.5-turbo');
  const [temperature, setTemperature] = useState('0.7');
  const [maxTokens, setMaxTokens] = useState('1000');
  const [isEnabled, setIsEnabled] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [isKeyValid, setIsKeyValid] = useState<boolean | null>(null);
  
  // Carregar configurações salvas
  useEffect(() => {
    const savedApiKey = localStorage.getItem('openai_api_key') || '';
    const savedModel = localStorage.getItem('openai_model') || 'gpt-3.5-turbo';
    const savedTemperature = localStorage.getItem('openai_temperature') || '0.7';
    const savedMaxTokens = localStorage.getItem('openai_max_tokens') || '1000';
    const savedIsEnabled = localStorage.getItem('openai_enabled') === 'true';
    
    setApiKey(savedApiKey);
    setModel(savedModel);
    setTemperature(savedTemperature);
    setMaxTokens(savedMaxTokens);
    setIsEnabled(savedIsEnabled);
    
    // Verificar se a API key é válida
    if (savedApiKey) {
      validateApiKey(savedApiKey);
    }
  }, []);
  
  // Validar API key
  const validateApiKey = async (key: string) => {
    setIsValidating(true);
    try {
      const service = new ChatGPTService({ apiKey: key });
      const isValid = await service.validateApiKey();
      setIsKeyValid(isValid);
      
      if (isValid) {
        toast({
          title: "Sucesso",
          description: "API key do ChatGPT validada com sucesso!",
          variant: "default"
        });
      } else {
        toast({
          title: "Erro",
          description: "API key do ChatGPT inválida. Verifique e tente novamente.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Erro ao validar API key:', error);
      setIsKeyValid(false);
      toast({
        title: "Erro",
        description: "Erro ao validar API key. Verifique sua conexão e tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsValidating(false);
    }
  };
  
  // Salvar configurações
  const saveSettings = () => {
    localStorage.setItem('openai_api_key', apiKey);
    localStorage.setItem('openai_model', model);
    localStorage.setItem('openai_temperature', temperature);
    localStorage.setItem('openai_max_tokens', maxTokens);
    localStorage.setItem('openai_enabled', isEnabled.toString());
    
    toast({
      title: "Sucesso",
      description: "Configurações de IA salvas com sucesso!",
      variant: "default"
    });
  };
  
  // Limpar configurações
  const clearSettings = () => {
    localStorage.removeItem('openai_api_key');
    localStorage.removeItem('openai_model');
    localStorage.removeItem('openai_temperature');
    localStorage.removeItem('openai_max_tokens');
    localStorage.removeItem('openai_enabled');
    
    setApiKey('');
    setModel('gpt-3.5-turbo');
    setTemperature('0.7');
    setMaxTokens('1000');
    setIsEnabled(false);
    setIsKeyValid(null);
    
    toast({
      title: "Sucesso",
      description: "Configurações de IA removidas com sucesso!",
      variant: "default"
    });
  };

  return (
    <Card className={cn(
      "border shadow-lg",
      isDarkMode ? "bg-card border-border" : "bg-white border-gray-200"
    )}>
      <CardHeader className="pb-4">
        <CardTitle className={cn(
          "flex items-center gap-3 text-lg",
          isDarkMode ? "text-card-foreground" : "text-gray-900"
        )}>
          <div className="p-2 rounded-lg bg-purple-100">
            <Brain className="h-5 w-5 text-purple-600" />
          </div>
          Configurações de Inteligência Artificial
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Status da IA */}
        <div className={cn(
          "p-4 rounded-lg border",
          isDarkMode ? "border-border bg-background/50" : "border-gray-200 bg-gray-50"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn(
                "p-2 rounded-full",
                isKeyValid === true 
                  ? "bg-green-100" 
                  : isKeyValid === false 
                    ? "bg-red-100" 
                    : "bg-gray-100"
              )}>
                {isKeyValid === true 
                  ? <Check className="h-5 w-5 text-green-600" /> 
                  : isKeyValid === false 
                    ? <AlertCircle className="h-5 w-5 text-red-600" /> 
                    : <Bot className="h-5 w-5 text-gray-600" />}
              </div>
              <div>
                <h4 className={cn(
                  "font-medium",
                  isDarkMode ? "text-card-foreground" : "text-gray-900"
                )}>
                  Status da Integração com ChatGPT
                </h4>
                <p className={cn(
                  "text-sm",
                  isDarkMode ? "text-muted-foreground" : "text-gray-600"
                )}>
                  {isKeyValid === true 
                    ? "API configurada e funcionando corretamente" 
                    : isKeyValid === false 
                      ? "API configurada, mas com problemas de conexão" 
                      : "API não configurada"}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <span className={cn(
                "text-sm",
                isDarkMode ? "text-muted-foreground" : "text-gray-600"
              )}>
                {isEnabled ? "Ativado" : "Desativado"}
              </span>
              <Switch
                checked={isEnabled}
                onCheckedChange={setIsEnabled}
              />
            </div>
          </div>
        </div>
        
        {/* API Key */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Key size={16} className="text-purple-600" />
            API Key do OpenAI
          </Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className={cn(
                  isDarkMode ? "bg-background border-border" : "bg-white border-gray-300"
                )}
              />
              <Lock size={16} className={cn(
                "absolute right-3 top-1/2 transform -translate-y-1/2",
                isDarkMode ? "text-muted-foreground" : "text-gray-400"
              )} />
            </div>
            <Button 
              onClick={() => validateApiKey(apiKey)}
              disabled={!apiKey || isValidating}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {isValidating ? "Validando..." : "Validar"}
            </Button>
          </div>
          <p className={cn(
            "text-xs",
            isDarkMode ? "text-muted-foreground" : "text-gray-500"
          )}>
            Obtenha sua API key em <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="underline text-purple-600">platform.openai.com/api-keys</a>
          </p>
        </div>
        
        {/* Modelo */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Sparkles size={16} className="text-purple-600" />
            Modelo
          </Label>
          <Select value={model} onValueChange={setModel}>
            <SelectTrigger className={cn(
              isDarkMode ? "bg-background border-border" : "bg-white border-gray-300"
            )}>
              <SelectValue placeholder="Selecione um modelo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo (Rápido e econômico)</SelectItem>
              <SelectItem value="gpt-3.5-turbo-16k">GPT-3.5 Turbo 16K (Contexto maior)</SelectItem>
              <SelectItem value="gpt-4">GPT-4 (Alta qualidade)</SelectItem>
              <SelectItem value="gpt-4-turbo">GPT-4 Turbo (Rápido e avançado)</SelectItem>
              <SelectItem value="gpt-4o">GPT-4o (Última geração)</SelectItem>
              <SelectItem value="gpt-4o-mini">GPT-4o Mini (Econômico e avançado)</SelectItem>
              <SelectItem value="claude-3-opus">Claude 3 Opus (Anthropic)</SelectItem>
              <SelectItem value="claude-3-sonnet">Claude 3 Sonnet (Anthropic)</SelectItem>
              <SelectItem value="claude-3-haiku">Claude 3 Haiku (Anthropic)</SelectItem>
              <SelectItem value="gemini-pro">Gemini Pro (Google)</SelectItem>
              <SelectItem value="llama-3-70b">Llama 3 70B (Meta)</SelectItem>
              <SelectItem value="mistral-large">Mistral Large</SelectItem>
            </SelectContent>
          </Select>
          <p className={cn(
            "text-xs",
            isDarkMode ? "text-muted-foreground" : "text-gray-500"
          )}>
            Modelos mais avançados oferecem melhores resultados, mas podem ter custo mais elevado
          </p>
        </div>
        
        {/* Configurações avançadas */}
        <div className={cn(
          "p-4 rounded-lg border",
          isDarkMode ? "border-border bg-background/50" : "border-gray-200 bg-gray-50"
        )}>
          <h4 className={cn(
            "font-medium mb-3 flex items-center gap-2",
            isDarkMode ? "text-card-foreground" : "text-gray-900"
          )}>
            <Settings size={16} className="text-purple-600" />
            Configurações Avançadas
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Temperatura */}
            <div className="space-y-2">
              <Label>Temperatura</Label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  className="flex-1"
                />
                <span className={cn(
                  "text-sm font-medium w-10 text-center",
                  isDarkMode ? "text-card-foreground" : "text-gray-900"
                )}>
                  {temperature}
                </span>
              </div>
              <p className={cn(
                "text-xs",
                isDarkMode ? "text-muted-foreground" : "text-gray-500"
              )}>
                Valores mais baixos = respostas mais previsíveis
              </p>
            </div>
            
            {/* Tokens máximos */}
            <div className="space-y-2">
              <Label>Tokens Máximos</Label>
              <Input
                type="number"
                value={maxTokens}
                onChange={(e) => setMaxTokens(e.target.value)}
                min="100"
                max="4000"
                className={cn(
                  isDarkMode ? "bg-background border-border" : "bg-white border-gray-300"
                )}
              />
              <p className={cn(
                "text-xs",
                isDarkMode ? "text-muted-foreground" : "text-gray-500"
              )}>
                Limite máximo de tokens por resposta (1000 recomendado)
              </p>
            </div>
          </div>
        </div>
        
        {/* Botões de ação */}
        <div className="flex justify-end gap-3 pt-4">
          <Button
            variant="outline"
            onClick={clearSettings}
            className={cn(
              isDarkMode ? "border-border text-card-foreground" : "border-gray-300"
            )}
          >
            Limpar Configurações
          </Button>
          <Button
            onClick={saveSettings}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            Salvar Configurações
          </Button>
        </div>
        
        {/* Informações de uso */}
        <div className={cn(
          "p-4 rounded-lg border mt-4",
          isDarkMode ? "border-border bg-background/50" : "border-gray-200 bg-gray-50"
        )}>
          <h4 className={cn(
            "font-medium mb-2 flex items-center gap-2",
            isDarkMode ? "text-card-foreground" : "text-gray-900"
          )}>
            <Shield size={16} className="text-purple-600" />
            Informações de Uso e Privacidade
          </h4>
          <p className={cn(
            "text-sm",
            isDarkMode ? "text-muted-foreground" : "text-gray-600"
          )}>
            A integração com ChatGPT permite gerar resumos de conversas, análises de sentimento e recomendações personalizadas. 
            Sua API key é armazenada apenas localmente no seu navegador e nunca é compartilhada com terceiros.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

