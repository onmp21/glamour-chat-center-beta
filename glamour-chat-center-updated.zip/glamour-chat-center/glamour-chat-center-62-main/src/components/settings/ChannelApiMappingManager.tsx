import React, { useState, useEffect } from 'react';
import { useChannelsDB } from '../../hooks/useChannelsDB';
import { useApiInstances } from '../../hooks/useApiInstances';
import { useChannelApiMappings } from '../../hooks/useChannelApiMappings';

export const ChannelApiMappingManager: React.FC = () => {
  const { channels, loading: loadingChannels } = useChannelsDB();
  const { instances, loading: loadingInstances } = useApiInstances();
  const { 
    mappings, 
    loading: loadingMappings, 
    upsertMapping, 
    deleteMapping 
  } = useChannelApiMappings();

  const [selectedInstances, setSelectedInstances] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (mappings.length > 0 && channels.length > 0) {
      const initialSelections: Record<string, string> = {};
      
      mappings.forEach(mapping => {
        initialSelections[mapping.channel_id] = mapping.api_instance_id;
      });
      
      setSelectedInstances(initialSelections);
    }
  }, [mappings, channels]);

  const handleInstanceChange = (channelId: string, instanceId: string) => {
    setSelectedInstances(prev => ({
      ...prev,
      [channelId]: instanceId
    }));
    
    // Clear any previous error
    if (errors[channelId]) {
      setErrors(prev => ({
        ...prev,
        [channelId]: ''
      }));
    }
  };

  const handleSaveMapping = async (channelId: string) => {
    const instanceId = selectedInstances[channelId];
    
    if (!instanceId) {
      setErrors(prev => ({
        ...prev,
        [channelId]: 'Selecione uma instância'
      }));
      return;
    }
    
    try {
      setSaving(prev => ({
        ...prev,
        [channelId]: true
      }));
      
      await upsertMapping(channelId, instanceId);
      
      // Clear error if successful
      setErrors(prev => ({
        ...prev,
        [channelId]: ''
      }));
    } catch (error) {
      console.error(`Error saving mapping for channel ${channelId}:`, error);
      setErrors(prev => ({
        ...prev,
        [channelId]: 'Falha ao salvar mapeamento'
      }));
    } finally {
      setSaving(prev => ({
        ...prev,
        [channelId]: false
      }));
    }
  };

  const handleClearMapping = async (channelId: string) => {
    try {
      setSaving(prev => ({
        ...prev,
        [channelId]: true
      }));
      
      await deleteMapping(channelId);
      
      setSelectedInstances(prev => {
        const updated = { ...prev };
        delete updated[channelId];
        return updated;
      });
    } catch (error) {
      console.error(`Error clearing mapping for channel ${channelId}:`, error);
      setErrors(prev => ({
        ...prev,
        [channelId]: 'Falha ao remover mapeamento'
      }));
    } finally {
      setSaving(prev => ({
        ...prev,
        [channelId]: false
      }));
    }
  };

  const isLoading = loadingChannels || loadingInstances || loadingMappings;

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-2">Atribuição de Instâncias aos Canais</h2>
        <p className="text-gray-600 mb-4">
          Selecione qual instância da API Evolution cada canal deve utilizar para enviar mensagens.
        </p>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Canal
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Instância da API
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {channels.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500">
                    Nenhum canal encontrado
                  </td>
                </tr>
              ) : (
                channels.map((channel) => (
                  <tr key={channel.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {channel.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <select
                        value={selectedInstances[channel.id] || ''}
                        onChange={(e) => handleInstanceChange(channel.id, e.target.value)}
                        className={`block w-full px-3 py-2 border rounded-md shadow-sm ${
                          errors[channel.id] ? 'border-red-500' : 'border-gray-300'
                        }`}
                      >
                        <option value="">Selecione uma instância</option>
                        {instances.map((instance) => (
                          <option key={instance.id} value={instance.id}>
                            {instance.instance_name}
                          </option>
                        ))}
                      </select>
                      {errors[channel.id] && (
                        <p className="mt-1 text-sm text-red-600">{errors[channel.id]}</p>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleSaveMapping(channel.id)}
                        disabled={saving[channel.id] || !selectedInstances[channel.id]}
                        className={`text-blue-600 hover:text-blue-900 mr-4 ${
                          saving[channel.id] || !selectedInstances[channel.id] ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      >
                        {saving[channel.id] ? 'Salvando...' : 'Salvar'}
                      </button>
                      {selectedInstances[channel.id] && (
                        <button
                          onClick={() => handleClearMapping(channel.id)}
                          disabled={saving[channel.id]}
                          className={`text-red-600 hover:text-red-900 ${
                            saving[channel.id] ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                        >
                          Remover
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

