import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { MessageSquare } from 'lucide-react';
import { ApiSettingsPage } from './ApiSettingsPage';

interface EvolutionAPISectionProps {
  isDarkMode: boolean;
}

export const EvolutionAPISection: React.FC<EvolutionAPISectionProps> = ({ isDarkMode }) => {
  return (
    <Card className={cn(
      "border shadow-lg",
      isDarkMode ? "bg-card border-border" : "bg-white border-gray-200"
    )}>
      <CardHeader className="pb-4">
        <CardTitle className={cn(
          "flex items-center gap-3 text-lg",
          isDarkMode ? "text-card-foreground" : "text-gray-900"
        )}>
          <div className="p-2 rounded-lg bg-[#b5103c]/10">
            <MessageSquare className="h-5 w-5 text-[#b5103c]" />
          </div>
          API Evolution
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <ApiSettingsPage />
      </CardContent>
    </Card>
  );
};

