import React, { useState, useEffect } from 'react';
import { ApiInstance } from '../../types/domain/api/ApiInstance';

interface ApiInstanceFormProps {
  instance?: ApiInstance;
  onSubmit: (instance: ApiInstance) => void;
  onCancel: () => void;
}

export const ApiInstanceForm: React.FC<ApiInstanceFormProps> = ({
  instance,
  onSubmit,
  onCancel
}) => {
  const [formData, setFormData] = useState<ApiInstance>({
    instance_name: '',
    base_url: '',
    api_key: ''
  });

  const [errors, setErrors] = useState<{
    instance_name?: string;
    base_url?: string;
    api_key?: string;
  }>({});

  useEffect(() => {
    if (instance) {
      setFormData({
        instance_name: instance.instance_name || '',
        base_url: instance.base_url || '',
        api_key: instance.api_key || ''
      });
    }
  }, [instance]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when field is edited
    if (errors[name as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: {
      instance_name?: string;
      base_url?: string;
      api_key?: string;
    } = {};
    
    if (!formData.instance_name.trim()) {
      newErrors.instance_name = 'Nome da instância é obrigatório';
    }
    
    if (!formData.base_url.trim()) {
      newErrors.base_url = 'URL base é obrigatória';
    } else if (!formData.base_url.startsWith('http://') && !formData.base_url.startsWith('https://')) {
      newErrors.base_url = 'URL base deve começar com http:// ou https://';
    }
    
    if (!formData.api_key.trim()) {
      newErrors.api_key = 'Chave de API é obrigatória';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit({
        ...formData,
        id: instance?.id
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-white rounded-lg shadow">
      <div>
        <label htmlFor="instance_name" className="block text-sm font-medium text-gray-700 mb-1">
          Nome da Instância
        </label>
        <input
          type="text"
          id="instance_name"
          name="instance_name"
          value={formData.instance_name}
          onChange={handleChange}
          className={`w-full px-3 py-2 border rounded-md ${
            errors.instance_name ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="Ex: Matriz-Irece"
        />
        {errors.instance_name && (
          <p className="mt-1 text-sm text-red-600">{errors.instance_name}</p>
        )}
      </div>

      <div>
        <label htmlFor="base_url" className="block text-sm font-medium text-gray-700 mb-1">
          URL Base
        </label>
        <input
          type="text"
          id="base_url"
          name="base_url"
          value={formData.base_url}
          onChange={handleChange}
          className={`w-full px-3 py-2 border rounded-md ${
            errors.base_url ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="Ex: https://api.evolution.com"
        />
        {errors.base_url && (
          <p className="mt-1 text-sm text-red-600">{errors.base_url}</p>
        )}
      </div>

      <div>
        <label htmlFor="api_key" className="block text-sm font-medium text-gray-700 mb-1">
          Chave de API
        </label>
        <input
          type="text"
          id="api_key"
          name="api_key"
          value={formData.api_key}
          onChange={handleChange}
          className={`w-full px-3 py-2 border rounded-md ${
            errors.api_key ? 'border-red-500' : 'border-gray-300'
          }`}
          placeholder="Sua chave de API"
        />
        {errors.api_key && (
          <p className="mt-1 text-sm text-red-600">{errors.api_key}</p>
        )}
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700"
        >
          {instance ? 'Atualizar' : 'Adicionar'}
        </button>
      </div>
    </form>
  );
};

