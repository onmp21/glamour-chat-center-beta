import React from 'react';
import { ReportDashboard } from './reports/ReportDashboard';
import { useTheme } from '../hooks/useTheme';

export const ReportCenter: React.FC = () => {
  const { isDarkMode } = useTheme();
  
  return (
    <div className="p-4 md:p-6">
      <ReportDashboard isDarkMode={isDarkMode} />
    </div>
  );
};

