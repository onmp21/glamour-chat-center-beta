import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { 
  BarChart3, 
  Calendar, 
  Users, 
  MessageSquare,
  Download,
  Eye,
  Plus,
  Search,
  TrendingUp,
  FileText,
  Filter,
  History,
  Loader2,
  X
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { EnhancedReportPDFService } from '@/services/EnhancedReportPDFService';
import { ReportPreviewModal } from './ReportPreviewModal';

interface ReportsNewProps {
  isDarkMode: boolean;
}

interface ReportHistory {
  id: string;
  title: string;
  type: string;
  generatedAt: string;
  size: string;
  downloadUrl?: string;
}

const reportTemplates = [
  {
    id: 'conversations-daily',
    title: 'Conversas Diárias',
    description: 'Relatório detalhado das conversas por dia',
    icon: MessageSquare,
    category: 'Conversas',
  },
  {
    id: 'conversations-channel',
    title: 'Conversas por Canal',
    description: 'Análise de conversas distribuídas por canal',
    icon: BarChart3,
    category: 'Conversas', 
  },
  {
    id: 'exams-monthly',
    title: 'Exames Mensais',
    description: 'Relatório mensal de exames agendados',
    icon: Calendar,
    category: 'Exames',
  },
  {
    id: 'users-activity',
    title: 'Atividade dos Usuários',
    description: 'Relatório de atividade e produtividade',
    icon: Users,
    category: 'Usuários',
  },
  {
    id: 'performance',
    title: 'Performance Geral',
    description: 'Indicadores de performance do sistema',
    icon: TrendingUp,
    category: 'Performance',
  }
];

// Dados mockados para demonstração
const generateMockData = (reportType: string) => {
  const baseData = {
    'conversations-daily': {
      totalConversations: 234,
      resolvedConversations: 187,
      pendingConversations: 47,
      averageResponseTime: '4.2 min',
      channels: [
        { name: 'Canarana', conversations: 45, resolved: 38 },
        { name: 'Souto Soares', conversations: 52, resolved: 41 },
        { name: 'João Dourado', conversations: 38, resolved: 29 },
        { name: 'América Dourada', conversations: 41, resolved: 35 },
      ]
    },
    'conversations-channel': {
      totalChannels: 7,
      activeChannels: 6,
      mostActiveChannel: 'Souto Soares',
      leastActiveChannel: 'Gerente Externo',
      channels: [
        { name: 'Souto Soares', conversations: 89, percentage: 28.5 },
        { name: 'Canarana', conversations: 76, percentage: 24.3 },
        { name: 'João Dourado', conversations: 54, percentage: 17.3 },
        { name: 'América Dourada', conversations: 48, percentage: 15.4 },
      ]
    },
    'exams-monthly': {
      totalExams: 156,
      completedExams: 142,
      canceledExams: 14,
      averageWaitTime: '2.3 dias',
      examTypes: [
        { type: 'Oftalmológico Completo', count: 89, percentage: 57.1 },
        { type: 'Consulta de Rotina', count: 34, percentage: 21.8 },
        { type: 'Exame de Vista', count: 33, percentage: 21.1 },
      ]
    },
    'users-activity': {
      totalUsers: 12,
      activeUsers: 10,
      averageSessionTime: '6.4 horas',
      mostActiveUser: 'Ana Silva',
      users: [
        { name: 'Ana Silva', sessions: 23, hours: 184.5 },
        { name: 'Carlos Santos', sessions: 19, hours: 152.3 },
        { name: 'Maria Oliveira', sessions: 17, hours: 136.7 },
      ]
    },
    'performance': {
      systemUptime: '99.8%',
      averageLoadTime: '1.2s',
      totalRequests: 15420,
      errorRate: '0.2%',
      metrics: [
        { metric: 'Tempo de Resposta', value: '245ms', status: 'Excelente' },
        { metric: 'Uso de CPU', value: '34%', status: 'Normal' },
        { metric: 'Uso de Memória', value: '67%', status: 'Normal' },
      ]
    }
  };

  return baseData[reportType as keyof typeof baseData] || {};
};

export const ReportsNew: React.FC<ReportsNewProps> = ({ isDarkMode }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedReports, setSelectedReports] = useState<string[]>([]);
  const [reportHistory, setReportHistory] = useState<ReportHistory[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('templates');
  const [previewReport, setPreviewReport] = useState<string | null>(null);
  const { toast } = useToast();

  const categories = ['all', 'Conversas', 'Exames', 'Usuários', 'Performance'];

  useEffect(() => {
    // Mock report history
    const mockHistory: ReportHistory[] = [
      {
        id: '1',
        title: 'Conversas Diárias - Janeiro 2024',
        type: 'conversations-daily',
        generatedAt: '2024-01-15T10:30:00Z',
        size: '2.3 MB'
      },
      {
        id: '2',
        title: 'Performance Geral - Dezembro 2023',
        type: 'performance',
        generatedAt: '2024-01-10T14:20:00Z',
        size: '1.8 MB'
      }
    ];
    setReportHistory(mockHistory);
  }, []);

  const filteredReports = reportTemplates.filter(report => {
    const matchesSearch = report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || report.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleReportSelect = (reportId: string) => {
    setSelectedReports(prev => 
      prev.includes(reportId) 
        ? prev.filter(id => id !== reportId)
        : [...prev, reportId]
    );
  };

  const handleGenerateReports = async () => {
    if (selectedReports.length === 0) {
      toast({
        title: "Erro",
        description: "Selecione pelo menos um relatório para gerar",
        variant: "destructive"
      });
      return;
    }
    
    setIsGenerating(true);
    
    try {
      for (const reportId of selectedReports) {
        const report = reportTemplates.find(r => r.id === reportId);
        if (!report) continue;

        const reportData = EnhancedReportPDFService.generateMockData(reportId);
        const doc = EnhancedReportPDFService.generatePDF(reportData);
        
        // Download PDF
        EnhancedReportPDFService.downloadPDF(doc, `${report.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}`);
        
        // Add to history
        const newHistoryItem: ReportHistory = {
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          title: `${report.title} - ${new Date().toLocaleDateString('pt-BR')}`,
          type: reportId,
          generatedAt: new Date().toISOString(),
          size: '2.1 MB'
        };
        
        setReportHistory(prev => [newHistoryItem, ...prev]);
      }
      
      toast({
        title: "Sucesso",
        description: `${selectedReports.length} relatório(s) gerado(s) com sucesso`,
      });
      
      setSelectedReports([]);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao gerar relatórios. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePreviewReport = (reportId: string) => {
    setPreviewReport(reportId);
  };

  return (
    <div className={cn(
      "flex-1 p-6 space-y-6 overflow-auto",
      isDarkMode ? "bg-[#09090b]" : "bg-gray-50"
    )}>
      {/* Header */}
      <div className="text-left">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 rounded-full bg-[#b5103c]/10">
            <BarChart3 size={32} className="text-[#b5103c]" strokeWidth={1.5} />
          </div>
          <div>
            <h1 className={cn(
              "text-3xl font-bold",
              isDarkMode ? "text-white" : "text-gray-900"
            )}>
              Central de Relatórios
            </h1>
            <p className={cn(
              "text-lg",
              isDarkMode ? "text-[#a1a1aa]" : "text-gray-600"
            )}>
              Gere relatórios detalhados com métricas reais em PDF
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="templates">Modelos de Relatórios</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-6">
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="Buscar relatórios..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={cn(
                  "pl-10",
                  isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
                )}
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2 text-[#b5103c]" />
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'Todas as categorias' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {selectedReports.length > 0 && (
              <Button 
                onClick={handleGenerateReports} 
                disabled={isGenerating}
                className="bg-[#b5103c] hover:bg-[#9d0e34] text-white"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Gerando...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Gerar PDF ({selectedReports.length})
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Report Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredReports.map((report) => (
              <Card 
                key={report.id}
                className={cn(
                  "cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg border-2",
                  selectedReports.includes(report.id) 
                    ? "ring-2 ring-[#b5103c] border-[#b5103c]" 
                    : "",
                  isDarkMode 
                    ? "bg-[#18181b] border-[#3f3f46] hover:border-[#b5103c]/50" 
                    : "bg-white border-gray-200 hover:border-[#b5103c]/50"
                )}
                onClick={() => handleReportSelect(report.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="p-2 rounded-lg bg-[#b5103c] text-white">
                      <report.icon className="w-5 h-5" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className={cn(
                        "font-medium truncate text-sm",
                        isDarkMode ? "text-white" : "text-gray-900"
                      )}>
                        {report.title}
                      </h3>
                      <Badge variant="secondary" className="text-xs mt-1">
                        {report.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className={cn(
                    "text-xs mb-4",
                    isDarkMode ? "text-[#a1a1aa]" : "text-gray-600"
                  )}>
                    {report.description}
                  </p>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePreviewReport(report.id);
                      }}
                      className="flex-1 text-xs"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Preview
                    </Button>
                    
                    <Button
                      variant={selectedReports.includes(report.id) ? "default" : "outline"}
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReportSelect(report.id);
                      }}
                      className={cn(
                        "flex-1 text-xs",
                        selectedReports.includes(report.id) && "bg-[#b5103c] hover:bg-[#9d0e34]"
                      )}
                    >
                      {selectedReports.includes(report.id) ? '✓ Selecionado' : 'Selecionar'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card className={cn(
            "border shadow-sm",
            isDarkMode ? "bg-[#18181b] border-[#3f3f46]" : "bg-white border-gray-200"
          )}>
            <CardHeader>
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-[#b5103c]" />
                <CardTitle className={cn(isDarkMode ? "text-white" : "text-gray-900")}>
                  Relatórios Gerados
                </CardTitle>
              </div>
              <CardDescription className={cn(isDarkMode ? "text-[#a1a1aa]" : "text-gray-600")}>
                Histórico de relatórios gerados anteriormente
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reportHistory.length > 0 ? (
                <div className="space-y-3">
                  {reportHistory.map((item) => (
                    <div
                      key={item.id}
                      className={cn(
                        "flex items-center justify-between p-3 rounded-lg border",
                        isDarkMode ? "border-[#3f3f46] bg-[#27272a]" : "border-gray-200 bg-gray-50"
                      )}
                    >
                      <div className="flex items-center space-x-3">
                        <FileText className="w-5 h-5 text-[#b5103c]" />
                        <div>
                          <p className={cn("font-medium text-sm", isDarkMode ? "text-white" : "text-gray-900")}>
                            {item.title}
                          </p>
                          <p className={cn("text-xs", isDarkMode ? "text-[#a1a1aa]" : "text-gray-600")}>
                            {new Date(item.generatedAt).toLocaleString('pt-BR')} • {item.size}
                          </p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className={cn("w-12 h-12 mx-auto mb-4", isDarkMode ? "text-[#a1a1aa]" : "text-gray-400")} />
                  <p className={cn("text-sm", isDarkMode ? "text-[#a1a1aa]" : "text-gray-600")}>
                    Nenhum relatório gerado ainda
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Preview Modal */}
      {previewReport && (
        <ReportPreviewModal
          reportId={previewReport}
          isDarkMode={isDarkMode}
          onClose={() => setPreviewReport(null)}
        />
      )}
    </div>
  );
};
