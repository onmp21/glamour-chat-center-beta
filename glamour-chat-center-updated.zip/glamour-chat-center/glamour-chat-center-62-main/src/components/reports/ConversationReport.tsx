
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DatePicker } from '@/components/ui/date-picker';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { 
  FileText, 
  Calendar, 
  MessageSquare,
  Download,
  Search,
  Filter,
  Sparkles,
  Brain,
  Bot,
  RefreshCw
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { EnhancedReportService } from '@/services/EnhancedReportService';
import { createChatGPTService } from '@/services/ChatGPTService';
import { getTableNameForChannel } from '@/utils/channelMapping';

interface ConversationReportProps {
  isDarkMode: boolean;
}

// Interface para conversas formatadas
interface FormattedConversation {
  id: number;
  contact_name: string;
  created_at: string;
  status: string;
  messages: any[];
  message: string;
  session_id: string;
}

// Interface para dados brutos das tabelas
interface RawConversationData {
  id: number;
  message: string;
  session_id: string;
  nome_do_contato?: string;
  Nome_do_contato?: string;
  [key: string]: any;
}

export const ConversationReport: React.FC<ConversationReportProps> = ({ isDarkMode }) => {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [channels, setChannels] = useState<any[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<string>('');
  const [startDate, setStartDate] = useState<Date | undefined>(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
  const [endDate, setEndDate] = useState<Date | undefined>(new Date());
  const [isAIAvailable, setIsAIAvailable] = useState(false);
  const [conversations, setConversations] = useState<FormattedConversation[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Verificar disponibilidade da IA
  useEffect(() => {
    const chatGPTService = createChatGPTService();
    setIsAIAvailable(!!chatGPTService);
  }, []);
  
  // Carregar canais
  useEffect(() => {
    const fetchChannels = async () => {
      try {
        const { data, error } = await supabase.from('channels').select('*');
        if (error) throw error;
        setChannels(data || []);
        if (data && data.length > 0) {
          setSelectedChannel(data[0].id);
        }
      } catch (error) {
        console.error('Erro ao carregar canais:', error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os canais",
          variant: "destructive"
        });
      }
    };
    
    fetchChannels();
  }, []);
  
  // Função para buscar conversas de uma tabela específica
  const fetchConversationsFromTable = async (tableName: string): Promise<RawConversationData[]> => {
    try {
      console.log(`Fetching data from table: ${tableName}`);
      
      // Use a more explicit approach to handle dynamic table queries
      let queryResult;
      
      try {
        queryResult = await supabase
          .from(tableName as any)
          .select('*')
          .limit(50)
          .order('id', { ascending: false });
      } catch (queryError) {
        console.error(`Direct query failed for table ${tableName}:`, queryError);
        return [];
      }
      
      const { data, error } = queryResult;
      
      if (error) {
        console.error(`Query error for table ${tableName}:`, error);
        return [];
      }
      
      // Validate that we have actual data and it's an array
      if (!data || !Array.isArray(data)) {
        console.warn(`No valid data returned from table ${tableName}`);
        return [];
      }
      
      // Type guard function to validate the data structure
      const isValidConversationData = (item: any): item is RawConversationData => {
        return item && 
               typeof item === 'object' && 
               typeof item.id === 'number' &&
               typeof item.message === 'string' && 
               typeof item.session_id === 'string';
      };
      
      // Filter and validate data
      const validData: RawConversationData[] = data.filter(isValidConversationData);
      
      console.log(`Valid data filtered: ${validData.length} items from ${data.length} total`);
      return validData;
    } catch (error) {
      console.error(`Erro ao buscar dados da tabela ${tableName}:`, error);
      return [];
    }
  };
  
  // Carregar conversas quando o canal ou datas mudam
  useEffect(() => {
    if (!selectedChannel || !startDate || !endDate) return;
    
    const fetchConversations = async () => {
      setIsLoading(true);
      try {
        const selectedChannelData = channels.find(c => c.id === selectedChannel);
        if (!selectedChannelData) return;
        
        // Usar o utilitário de mapeamento para obter o nome da tabela
        const tableName = getTableNameForChannel(selectedChannelData.type);
        const data = await fetchConversationsFromTable(tableName);
        
        // Transformar os dados para um formato consistente
        const formattedConversations: FormattedConversation[] = data.map(conv => ({
          id: conv.id,
          contact_name: conv.nome_do_contato || conv.Nome_do_contato || 'Cliente',
          created_at: new Date().toISOString(),
          status: 'closed',
          messages: [],
          message: conv.message || '',
          session_id: conv.session_id || ''
        }));
        
        setConversations(formattedConversations);
      } catch (error) {
        console.error('Erro ao carregar conversas:', error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar as conversas",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchConversations();
  }, [selectedChannel, startDate, endDate, channels]);
  
  // Gerar relatório de conversas
  const handleGenerateReport = async () => {
    if (!selectedChannel || !startDate || !endDate) {
      toast({
        title: "Dados incompletos",
        description: "Selecione um canal e defina o período",
        variant: "destructive"
      });
      return;
    }
    
    if (conversations.length === 0) {
      toast({
        title: "Sem dados",
        description: "Não há conversas no período selecionado",
        variant: "destructive"
      });
      return;
    }
    
    setIsGenerating(true);
    
    try {
      const selectedChannelData = channels.find(c => c.id === selectedChannel);
      const channelName = selectedChannelData?.name || 'Canal';
      
      const reportService = new EnhancedReportService();
      const doc = await reportService.generateConversationReport(
        channelName,
        conversations,
        {
          start: startDate.toISOString(),
          end: endDate.toISOString()
        }
      );
      
      // Download do PDF
      const filename = `relatorio_conversas_${channelName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}`;
      doc.save(`${filename}.pdf`);
      
      toast({
        title: "Relatório gerado!",
        description: `Relatório de conversas do canal ${channelName} gerado com sucesso`,
      });
    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
      toast({
        title: "Erro",
        description: "Erro ao gerar relatório. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Atualizar conversas
  const handleRefreshConversations = async () => {
    if (!selectedChannel || !startDate || !endDate) return;
    
    setIsLoading(true);
    try {
      const selectedChannelData = channels.find(c => c.id === selectedChannel);
      if (!selectedChannelData) return;
      
      const tableName = getTableNameForChannel(selectedChannelData.type);
      const data = await fetchConversationsFromTable(tableName);
      
      const formattedConversations: FormattedConversation[] = data.map(conv => ({
        id: conv.id,
        contact_name: conv.nome_do_contato || conv.Nome_do_contato || 'Cliente',
        created_at: new Date().toISOString(),
        status: 'closed',
        messages: [],
        message: conv.message || '',
        session_id: conv.session_id || ''
      }));
      
      setConversations(formattedConversations);
      
      toast({
        title: "Dados atualizados",
        description: `${data.length || 0} conversas carregadas`,
      });
    } catch (error) {
      console.error('Erro ao atualizar conversas:', error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar as conversas",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={cn(
      "p-6",
      isDarkMode ? "bg-background" : "bg-gray-50"
    )}>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Cabeçalho */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className={cn(
              "text-2xl font-bold",
              isDarkMode ? "text-white" : "text-gray-900"
            )}>
              Relatório de Conversas por Canal
            </h2>
            <p className={cn(
              "text-sm",
              isDarkMode ? "text-muted-foreground" : "text-gray-600"
            )}>
              Gere relatórios detalhados das conversas por canal com resumo e análise
            </p>
          </div>
          
          {isAIAvailable ? (
            <div className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-lg",
              isDarkMode ? "bg-green-900/20 text-green-400" : "bg-green-100 text-green-700"
            )}>
              <Brain size={18} />
              <span className="text-sm font-medium">IA Ativada</span>
            </div>
          ) : (
            <div className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-lg",
              isDarkMode ? "bg-yellow-900/20 text-yellow-400" : "bg-yellow-100 text-yellow-700"
            )}>
              <Bot size={18} />
              <span className="text-sm font-medium">IA Desativada</span>
            </div>
          )}
        </div>
        
        {/* Filtros */}
        <Card className={cn(
          "border",
          isDarkMode ? "bg-card border-border" : "bg-white border-gray-200"
        )}>
          <CardHeader className="pb-4">
            <CardTitle className={cn(
              "flex items-center gap-3 text-lg",
              isDarkMode ? "text-card-foreground" : "text-gray-900"
            )}>
              <Filter size={18} className="text-[#b5103c]" />
              Filtros do Relatório
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Canal</Label>
                <Select value={selectedChannel} onValueChange={setSelectedChannel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um canal" />
                  </SelectTrigger>
                  <SelectContent>
                    {channels.map(channel => (
                      <SelectItem key={channel.id} value={channel.id}>
                        {channel.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label>Data Inicial</Label>
                  <DatePicker
                    date={startDate}
                    setDate={setStartDate}
                    className={cn(
                      isDarkMode ? "bg-background border-border" : "bg-white border-gray-300"
                    )}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Data Final</Label>
                  <DatePicker
                    date={endDate}
                    setDate={setEndDate}
                    className={cn(
                      isDarkMode ? "bg-background border-border" : "bg-white border-gray-300"
                    )}
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefreshConversations}
                disabled={isLoading}
                className="flex items-center gap-2"
              >
                <RefreshCw size={16} className={isLoading ? "animate-spin" : ""} />
                {isLoading ? "Carregando..." : "Atualizar Dados"}
              </Button>
              
              <Button
                onClick={handleGenerateReport}
                disabled={isGenerating || conversations.length === 0}
                className="bg-[#b5103c] hover:bg-[#9a0e35] text-white flex items-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <Sparkles size={16} className="animate-pulse" />
                    Gerando Relatório...
                  </>
                ) : (
                  <>
                    <FileText size={16} />
                    Gerar Relatório PDF
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Preview de dados */}
        <Card className={cn(
          "border",
          isDarkMode ? "bg-card border-border" : "bg-white border-gray-200"
        )}>
          <CardHeader className="pb-4">
            <CardTitle className={cn(
              "flex items-center gap-3 text-lg",
              isDarkMode ? "text-card-foreground" : "text-gray-900"
            )}>
              <MessageSquare size={18} className="text-[#b5103c]" />
              Dados para o Relatório
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className={cn("mt-2 text-sm", isDarkMode ? "text-muted-foreground" : "text-gray-600")}>
                  Carregando conversas...
                </p>
              </div>
            ) : conversations.length > 0 ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <p className={cn(
                    "text-sm font-medium",
                    isDarkMode ? "text-card-foreground" : "text-gray-900"
                  )}>
                    {conversations.length} conversas encontradas
                  </p>
                  
                  {isAIAvailable && (
                    <div className={cn(
                      "flex items-center gap-2 px-3 py-1 rounded-full text-xs",
                      isDarkMode ? "bg-purple-900/20 text-purple-400" : "bg-purple-100 text-purple-700"
                    )}>
                      <Sparkles size={14} />
                      <span>Resumo com IA disponível</span>
                    </div>
                  )}
                </div>
                
                <div className={cn(
                  "border rounded-lg overflow-hidden",
                  isDarkMode ? "border-border" : "border-gray-200"
                )}>
                  <div className={cn(
                    "grid grid-cols-4 gap-4 p-3 text-sm font-medium",
                    isDarkMode ? "bg-background/50" : "bg-gray-50"
                  )}>
                    <div>Cliente</div>
                    <div>Data</div>
                    <div>Mensagens</div>
                    <div>Status</div>
                  </div>
                  
                  <div className="divide-y divide-gray-200 dark:divide-gray-800">
                    {conversations.slice(0, 5).map((conv, index) => (
                      <div key={index} className="grid grid-cols-4 gap-4 p-3 text-sm">
                        <div className={cn(
                          "font-medium",
                          isDarkMode ? "text-card-foreground" : "text-gray-900"
                        )}>
                          {conv.contact_name || 'Cliente'}
                        </div>
                        <div className={cn(
                          isDarkMode ? "text-muted-foreground" : "text-gray-600"
                        )}>
                          {new Date(conv.created_at).toLocaleDateString('pt-BR')}
                        </div>
                        <div className={cn(
                          isDarkMode ? "text-muted-foreground" : "text-gray-600"
                        )}>
                          {conv.messages?.length || 0}
                        </div>
                        <div>
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            conv.status === 'closed' 
                              ? (isDarkMode ? "bg-green-900/20 text-green-400" : "bg-green-100 text-green-700")
                              : (isDarkMode ? "bg-blue-900/20 text-blue-400" : "bg-blue-100 text-blue-700")
                          )}>
                            {conv.status === 'closed' ? 'Finalizada' : 'Ativa'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {conversations.length > 5 && (
                    <div className={cn(
                      "p-3 text-center text-sm",
                      isDarkMode ? "bg-background/50 text-muted-foreground" : "bg-gray-50 text-gray-600"
                    )}>
                      ... e mais {conversations.length - 5} conversas
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <MessageSquare size={48} className={cn(
                  "mx-auto mb-4",
                  isDarkMode ? "text-muted-foreground" : "text-gray-400"
                )} />
                <p className={cn("text-sm", isDarkMode ? "text-muted-foreground" : "text-gray-600")}>
                  Nenhuma conversa encontrada no período selecionado
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Informações sobre o relatório */}
        <Card className={cn(
          "border",
          isDarkMode ? "bg-card border-border" : "bg-white border-gray-200"
        )}>
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <div className={cn(
                "p-3 rounded-lg flex-shrink-0",
                isDarkMode ? "bg-background" : "bg-gray-100"
              )}>
                <Brain size={24} className="text-[#b5103c]" />
              </div>
              
              <div>
                <h3 className={cn(
                  "text-lg font-medium mb-1",
                  isDarkMode ? "text-card-foreground" : "text-gray-900"
                )}>
                  Relatório Inteligente de Conversas
                </h3>
                
                <p className={cn(
                  "text-sm",
                  isDarkMode ? "text-muted-foreground" : "text-gray-600"
                )}>
                  Este relatório inclui um resumo detalhado das conversas, análise de sentimento e recomendações geradas por IA.
                  {!isAIAvailable && ' Para ativar os recursos de IA, configure a API do ChatGPT nas configurações do sistema.'}
                </p>
                
                {!isAIAvailable && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      // Navegar para a página de configurações de IA
                      window.location.href = '#/settings/ai';
                    }}
                  >
                    Configurar API do ChatGPT
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
