import React from 'react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { YelenaMessageDisplay } from './YelenaMessageDisplay';
import { AndressaMessageDisplay } from './AndressaMessageDisplay';

interface ChatMessageProps {
  message: {
    id: string;
    content: string;
    timestamp: string;
    sender: string;
    tipo_remetente?: string;
    isOwn?: boolean;
    agentName?: string;
    Nome_do_contato?: string;
    nome_do_contato?: string;
    mensagemtype?: string;
  };
  isDarkMode: boolean;
  channelId?: string;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ 
  message, 
  isDarkMode, 
  channelId 
}) => {
  // Se for canal Yelena, usar o YelenaMessageDisplay
  if (channelId === 'chat' || channelId === 'af1e5797-edc6-4ba3-a57a-25cf7297c4d6') {
    return (
      <YelenaMessageDisplay 
        message={message} 
        isDarkMode={isDarkMode} 
      />
    );
  }

  // Se for canal Andressa (gerente-externo), usar o AndressaMessageDisplay
  if (channelId === 'd2892900-ca8f-4b08-a73f-6b7aa5866ff7' || channelId === 'gerente-externo') {
    return (
      <AndressaMessageDisplay 
        message={message} 
        isDarkMode={isDarkMode} 
      />
    );
  }

  const { user } = useAuth();
  
  // Determine if the message is from an agent based on tipo_remetente or sender
  const isAgent = 
    message.tipo_remetente === 'USUARIO_INTERNO' || 
    message.tipo_remetente === 'Yelena-ai' ||
    message.sender === 'agent' || 
    message.isOwn;
  
  // Get the correct name from Nome_do_contato, nome_do_contato, or default to sender name
  const displayName = isAgent 
    ? (message.agentName || 'Agente') 
    : (message.Nome_do_contato || message.nome_do_contato || message.sender || 'Cliente');

  const renderMessageContent = () => {
    // Se for uma imagem (data:image/...)
    if (message.content.startsWith('data:image/')) {
      return (
        <img 
          src={message.content} 
          alt="Imagem enviada" 
          className="chat-message-media"
          onClick={() => window.open(message.content, '_blank')}
        />
      );
    }
    
    // Se for um áudio (data:audio/...)
    if (message.content.startsWith('data:audio/')) {
      return (
        <audio controls className="chat-message-audio">
          <source src={message.content} />
          Seu navegador não suporta áudio.
        </audio>
      );
    }
    
    // Se for um vídeo (data:video/...)
    if (message.content.startsWith('data:video/')) {
      return (
        <video controls className="chat-message-media">
          <source src={message.content} />
          Seu navegador não suporta vídeo.
        </video>
      );
    }
    
    // Se for um arquivo/documento
    if (message.mensagemtype && message.mensagemtype !== 'text' && !message.content.startsWith('data:')) {
      return (
        <div className="chat-message-document">
          <span className="mr-2">📎</span>
          <span>Arquivo enviado</span>
        </div>
      );
    }
    
    // Texto normal
    return <p className="chat-message-text">{message.content}</p>;
  };

  return (
    <div className={cn(
      "chat-message-whatsapp message-animate",
      isAgent ? "sent" : "received"
    )}>
      {!isAgent && (
        <div className="chat-message-sender" style={{ color: isDarkMode ? '#e9edef' : '#303030' }}>
          {displayName}
        </div>
      )}
      
      {/* Conteúdo da mensagem */}
      <div>
        {renderMessageContent()}
      </div>
      
      {/* Timestamp */}
      <div className="chat-message-timestamp">
        {new Date(message.timestamp).toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit'
        })}
      </div>
    </div>
  );
};

