import React from 'react';
import { cn } from '@/lib/utils';

interface AndressaMessageDisplayProps {
  message: {
    id: string;
    content: string;
    timestamp: string;
    sender: string;
    tipo_remetente?: string;
    isOwn?: boolean;
    agentName?: string;
    Nome_do_contato?: string;
    nome_do_contato?: string;
    mensagemtype?: string;
  };
  isDarkMode: boolean;
}

export const AndressaMessageDisplay: React.FC<AndressaMessageDisplayProps> = ({ 
  message, 
  isDarkMode 
}) => {
  // Determine if the message is from an agent based on tipo_remetente or sender
  const isAgent = 
    message.tipo_remetente === 'USUARIO_INTERNO' || 
    message.tipo_remetente === 'Andressa-ai' ||
    message.sender === 'agent' || 
    message.isOwn;
  
  // Get the correct name from Nome_do_contato, nome_do_contato, or default to sender name
  const displayName = isAgent 
    ? (message.agentName || 'Andressa') 
    : (message.Nome_do_contato || message.nome_do_contato || message.sender || 'Cliente');

  const renderMessageContent = () => {
    // Se for uma imagem (data:image/...)
    if (message.content.startsWith('data:image/')) {
      return (
        <img 
          src={message.content} 
          alt="Imagem enviada" 
          className="chat-message-media"
          onClick={() => window.open(message.content, '_blank')}
        />
      );
    }
    
    // Se for um áudio (data:audio/...)
    if (message.content.startsWith('data:audio/')) {
      return (
        <audio controls className="chat-message-audio">
          <source src={message.content} />
          Seu navegador não suporta áudio.
        </audio>
      );
    }
    
    // Se for um vídeo (data:video/...)
    if (message.content.startsWith('data:video/')) {
      return (
        <video controls className="chat-message-media">
          <source src={message.content} />
          Seu navegador não suporta vídeo.
        </video>
      );
    }
    
    // Se for um arquivo/documento
    if (message.mensagemtype && message.mensagemtype !== 'text' && !message.content.startsWith('data:')) {
      return (
        <div className="chat-message-document">
          <span className="mr-2">📎</span>
          <span>Arquivo enviado</span>
        </div>
      );
    }
    
    // Texto normal
    return <p className="chat-message-text">{message.content}</p>;
  };

  return (
    <div className={cn(
      "chat-message-whatsapp message-animate",
      isAgent ? "sent" : "received"
    )}>
      {!isAgent && (
        <div className="chat-message-sender" style={{ color: isDarkMode ? '#e9edef' : '#303030' }}>
          {displayName}
        </div>
      )}
      
      {/* Conteúdo da mensagem */}
      <div>
        {renderMessageContent()}
      </div>
      
      {/* Timestamp */}
      <div className="chat-message-timestamp">
        {new Date(message.timestamp).toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit'
        })}
      </div>
    </div>
  );
};

