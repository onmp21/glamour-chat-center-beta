import React, { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { MediaProcessor, MediaResult } from '@/services/MediaProcessor';

interface MediaMessageRendererProps {
  content: string;
  messageType: string;
  messageId: string;
  isDarkMode?: boolean;
  fileName?: string;
}

export const MediaMessageRenderer: React.FC<MediaMessageRendererProps> = ({
  content,
  messageType,
  messageId,
  isDarkMode = false,
  fileName
}) => {
  const [mediaError, setMediaError] = useState(false);
  const [audioLoaded, setAudioLoaded] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Processar conteúdo sempre que mudar
  const processedResult = React.useMemo(() => {
    const result = MediaProcessor.process(content, messageType);
    console.log('🎯 [MEDIA_RENDERER] Processing result:', {
      messageId,
      messageType,
      resultType: result.type,
      hasDataUrl: result.url.startsWith('data:'),
      urlLength: result.url.length
    });
    return result;
  }, [content, messageType, messageId]);

  // Resetar estados quando o conteúdo mudar
  useEffect(() => {
    setMediaError(false);
    setAudioLoaded(false);
  }, [processedResult.url]);

  const renderPlaceholder = () => {
    const icon = MediaProcessor.getMediaIcon(processedResult.type);
    
    return (
      <div className={cn(
        "p-3 rounded-lg border flex items-center gap-2 max-w-xs",
        isDarkMode ? "bg-gray-700 border-gray-600 text-gray-200" : "bg-gray-50 border-gray-200 text-gray-700"
      )}>
        <span className="text-lg">{icon}</span>
        <span className="text-sm">{processedResult.url}</span>
      </div>
    );
  };

  const renderError = () => {
    const icon = MediaProcessor.getMediaIcon(processedResult.type);
    
    return (
      <div className={cn(
        "p-3 rounded-lg border text-center max-w-xs",
        isDarkMode ? "bg-red-900/20 border-red-800 text-red-400" : "bg-red-50 border-red-200 text-red-600"
      )}>
        <div className="text-2xl mb-2">{icon}</div>
        <div className="text-sm">Erro ao carregar mídia</div>
        <div className="text-xs mt-1 opacity-70">Tente recarregar a página</div>
      </div>
    );
  };

  const renderAudio = () => {
    return (
      <div className="max-w-xs">
        <div className={cn(
          "p-3 rounded-lg border flex items-center",
          isDarkMode ? "bg-gray-700 border-gray-600" : "bg-gray-50 border-gray-200"
        )}>
          <div className="flex-shrink-0 mr-3">
            <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
              <span className="text-lg">🎵</span>
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-col">
              <span className={cn(
                "text-sm font-medium",
                isDarkMode ? "text-gray-200" : "text-gray-700"
              )}>
                Mensagem de áudio
              </span>
              {processedResult.size && (
                <span className={cn(
                  "text-xs",
                  isDarkMode ? "text-gray-400" : "text-gray-500"
                )}>
                  {processedResult.size}
                </span>
              )}
            </div>
            
            {mediaError ? (
              <div className="text-center p-2">
                <div className="text-sm text-red-500">❌ Erro ao carregar áudio</div>
              </div>
            ) : (
              <div className="mt-2">
                <audio 
                  ref={audioRef}
                  controls 
                  className="w-full" 
                  preload="metadata"
                  onLoadedData={() => {
                    console.log('✅ [AUDIO] Audio data loaded for:', messageId);
                    setAudioLoaded(true);
                  }}
                  onError={(e) => {
                    console.error('❌ [AUDIO] Error loading audio:', messageId, e);
                    setMediaError(true);
                  }}
                  onCanPlay={() => {
                    console.log('✅ [AUDIO] Audio can play:', messageId);
                  }}
                >
                  <source src={processedResult.url} type="audio/mpeg" />
                  <source src={processedResult.url} type="audio/ogg" />
                  <source src={processedResult.url} type="audio/wav" />
                  Seu navegador não suporta áudio
                </audio>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderImage = () => {
    if (mediaError) return renderError();
    
    return (
      <div className="max-w-xs">
        <div className="rounded-lg overflow-hidden border shadow-sm">
          <img 
            src={processedResult.url} 
            alt="Imagem enviada" 
            className="max-w-full max-h-48 w-full object-cover cursor-pointer"
            onClick={() => window.open(processedResult.url, '_blank')}
            onError={() => {
              console.error('❌ [IMAGE] Error loading image:', messageId);
              setMediaError(true);
            }}
            onLoad={() => {
              console.log('✅ [IMAGE] Image loaded:', messageId);
            }}
          />
          {processedResult.size && (
            <div className={cn(
              "text-xs p-2",
              isDarkMode ? "bg-gray-700 text-gray-400" : "bg-gray-50 text-gray-500"
            )}>
              {processedResult.size}
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderVideo = () => {
    if (mediaError) return renderError();
    
    return (
      <div className="max-w-xs">
        <div className="rounded-lg overflow-hidden border shadow-sm">
          <video 
            controls 
            className="max-w-full max-h-48 w-full" 
            preload="metadata"
            onError={() => {
              console.error('❌ [VIDEO] Error loading video:', messageId);
              setMediaError(true);
            }}
            onLoadedMetadata={() => {
              console.log('✅ [VIDEO] Video loaded:', messageId);
            }}
          >
            <source src={processedResult.url} type="video/mp4" />
            <source src={processedResult.url} type="video/webm" />
            <source src={processedResult.url} type="video/ogg" />
            Seu navegador não suporta vídeo
          </video>
          {processedResult.size && (
            <div className={cn(
              "text-xs p-2",
              isDarkMode ? "bg-gray-700 text-gray-400" : "bg-gray-50 text-gray-500"
            )}>
              {processedResult.size}
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderDocument = () => {
    const displayName = fileName || 'Documento';
    
    const handleDownload = () => {
      try {
        const link = document.createElement('a');
        link.href = processedResult.url;
        link.download = displayName;
        link.click();
        console.log('✅ [DOCUMENT] Download initiated:', displayName);
      } catch (error) {
        console.error('❌ [DOCUMENT] Error downloading:', error);
      }
    };

    return (
      <div 
        className={cn(
          "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all duration-200 max-w-xs hover:shadow-md",
          isDarkMode ? "bg-gray-700 border-gray-600 hover:bg-gray-650" : "bg-gray-50 border-gray-200 hover:bg-gray-100"
        )}
        onClick={handleDownload}
      >
        <div className={cn(
          "flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-lg",
          isDarkMode ? "bg-gray-600" : "bg-white shadow-sm"
        )}>
          📎
        </div>
        
        <div className="flex-1 min-w-0">
          <div className={cn(
            "font-medium text-sm truncate",
            isDarkMode ? "text-white" : "text-gray-900"
          )}>
            {displayName}
          </div>
          {processedResult.size && (
            <div className={cn(
              "text-xs",
              isDarkMode ? "text-gray-400" : "text-gray-500"
            )}>
              {processedResult.size}
            </div>
          )}
        </div>
      </div>
    );
  };

  // Tentar detectar se é base64 mesmo que o tipo seja texto
  const isLikelyBase64 = React.useMemo(() => {
    if (processedResult.type === 'text' && processedResult.url.length > 100) {
      // Verificar se parece com base64
      const cleaned = processedResult.url.replace(/\s/g, '');
      const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
      return base64Regex.test(cleaned);
    }
    return false;
  }, [processedResult]);

  // Renderizar baseado no tipo
  switch (processedResult.type) {
    case 'placeholder':
      return renderPlaceholder();
    case 'image':
      return renderImage();
    case 'audio':
      return renderAudio();
    case 'video':
      return renderVideo();
    case 'document':
      return renderDocument();
    case 'text':
    default:
      // Se parece base64 mas está sendo tratado como texto, mostrar aviso
      if (isLikelyBase64) {
        return (
          <div className={cn(
            "p-3 rounded-lg border text-center max-w-xs",
            isDarkMode ? "bg-yellow-900/20 border-yellow-800 text-yellow-400" : "bg-yellow-50 border-yellow-200 text-yellow-600"
          )}>
            <div className="text-2xl mb-2">📄</div>
            <div className="text-sm">Possível conteúdo base64 não processado</div>
            <div className="text-xs mt-1 opacity-70">Conteúdo muito longo para exibir</div>
          </div>
        );
      }
      return <p className="break-words whitespace-pre-wrap">{processedResult.url}</p>;
  }
};

